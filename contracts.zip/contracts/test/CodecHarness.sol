// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import { OFTComposeMsgCodec } from "@layerzerolabs/oft-evm/contracts/libs/OFTComposeMsgCodec.sol";
import "../libraries/Codec.sol";

/// @notice Test-only: compares our parsers with LayerZero's official OFTComposeMsgCodec.
contract CodecHarness {
    function officialEncode(uint64 nonce, uint32 srcEid, uint256 amountLD, bytes32 composeFrom, bytes memory composeMsg)
        external pure returns (bytes memory)
    {
        return OFTComposeMsgCodec.encode(nonce, srcEid, amountLD, abi.encodePacked(composeFrom, composeMsg));
    }

    function ours(bytes calldata m) external pure returns (uint32 srcEid, uint256 amountLD, address composeFrom, bytes memory composeMsg) {
        return OFTCompose.parse(m);
    }

    function official(bytes calldata m) external pure returns (uint32 srcEid, uint256 amountLD, bytes32 composeFrom, bytes memory composeMsg) {
        return (OFTComposeMsgCodec.srcEid(m), OFTComposeMsgCodec.amountLD(m), OFTComposeMsgCodec.composeFrom(m), OFTComposeMsgCodec.composeMsg(m));
    }

    function lzComposeOption(uint128 gas) external pure returns (bytes memory) { return LzOptions.compose(gas); }
}
