// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./access/RegistryOwned.sol";

/**
 * @title ChainConfig
 * @notice Chain registry: parameters for the local chain and for every remote chain.
 *         The remote `hub` address is the trust anchor used to authenticate bridge messages.
 *
 *  - CCTP support is decided only by `cctpEnabled` (domain 0 is Ethereum, not "unsupported").
 *  - Re-configuring a chain clears its stale EID / domain reverse mappings.
 */
contract ChainConfig is RegistryOwned {
    struct ChainParams {
        bool    enabled;        // transfers to this chain allowed
        bool    cctpEnabled;    // CCTP V2 supported
        uint32  cctpDomain;     // Circle domain (ETH 0, AVAX 1, OP 2, ARB 3, BASE 6, POLYGON 7)
        uint32  lzEid;          // LayerZero V2 EID (0 = no Stargate)
        address usdc;           // USDC on that chain
        uint8   usdcDecimals;   // 6 (18 on BSC)
        address wrappedNative;  // WETH/WPOL/WAVAX/WBNB
        address uniswapRouter;  // Uniswap UniversalRouter
        address stargatePool;   // Stargate V2 USDC pool
        address hub;            // CrossChainSwapHub on that chain
        uint128 lzComposeGas;   // gas forwarded to lzCompose on that chain
    }

    mapping(uint256 => ChainParams) private _chains;
    mapping(uint32 => uint256) public eidToChainId;
    mapping(uint32 => uint256) public domainToChainId;
    uint256[] private _chainIds;
    mapping(uint256 => bool) private _known;

    event ChainConfigured(uint256 indexed chainId, ChainParams p);
    event HubSet(uint256 indexed chainId, address hub);
    event ChainEnabled(uint256 indexed chainId, bool enabled);

    error InvalidParams();
    error EidTaken(uint32 eid, uint256 chainId);
    error DomainTaken(uint32 domain, uint256 chainId);

    constructor(address registry) RegistryOwned(registry) {}

    function setChain(uint256 chainId, ChainParams calldata p) external onlyOwner {
        if (chainId == 0 || p.usdc == address(0)) revert InvalidParams();
        if (p.lzEid != 0 && p.stargatePool == address(0)) revert InvalidParams();

        // clear stale reverse mappings
        ChainParams storage old = _chains[chainId];
        if (old.lzEid != 0 && eidToChainId[old.lzEid] == chainId) delete eidToChainId[old.lzEid];
        if (old.cctpEnabled && domainToChainId[old.cctpDomain] == chainId) delete domainToChainId[old.cctpDomain];

        if (p.lzEid != 0) {
            uint256 other = eidToChainId[p.lzEid];
            if (other != 0 && other != chainId) revert EidTaken(p.lzEid, other);
            eidToChainId[p.lzEid] = chainId;
        }
        if (p.cctpEnabled) {
            uint256 other = domainToChainId[p.cctpDomain];
            if (other != 0 && other != chainId) revert DomainTaken(p.cctpDomain, other);
            domainToChainId[p.cctpDomain] = chainId;
        }

        _chains[chainId] = p;
        if (!_known[chainId]) { _known[chainId] = true; _chainIds.push(chainId); }
        emit ChainConfigured(chainId, p);
    }

    /// @notice Update only the hub address of a known chain (used by `wire`).
    function setHub(uint256 chainId, address hub) external onlyOwner {
        if (!_known[chainId]) revert InvalidParams();
        _chains[chainId].hub = hub;
        emit HubSet(chainId, hub);
    }

    function setEnabled(uint256 chainId, bool enabled) external onlyOwner {
        if (!_known[chainId]) revert InvalidParams();
        _chains[chainId].enabled = enabled;
        emit ChainEnabled(chainId, enabled);
    }

    function getChain(uint256 chainId) external view returns (ChainParams memory) { return _chains[chainId]; }
    function chainIds() external view returns (uint256[] memory) { return _chainIds; }
}
