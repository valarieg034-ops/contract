// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// =====================================================================
// Test-only mocks. Never deployed to production.
// Interfaces and byte formats mirror the real CCTP / Stargate / Uniswap / Permit2 contracts.
// =====================================================================

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "../interfaces/IExternal.sol";

contract MockERC20 is ERC20 {
    uint8 private immutable _dec;
    mapping(address => bool) public blocked;
    constructor(string memory n, string memory s, uint8 d) ERC20(n, s) { _dec = d; }
    function decimals() public view override returns (uint8) { return _dec; }
    function mint(address to, uint256 a) external { _mint(to, a); }
    function burnFrom_(address from, uint256 a) external { _burn(from, a); }
    function setBlocked(address a, bool b) external { blocked[a] = b; }
    function _update(address from, address to, uint256 v) internal override {
        require(!blocked[to] && !blocked[from], "blocked");
        super._update(from, to, v);
    }
}

contract MockWETH is ERC20 {
    constructor() ERC20("Wrapped Native", "WNATIVE") {}
    function deposit() public payable { _mint(msg.sender, msg.value); }
    function withdraw(uint256 a) external { _burn(msg.sender, a); payable(msg.sender).transfer(a); }
    receive() external payable { deposit(); }
}

contract MockAggregator is IAggregatorV3 {
    int256 public answer; uint8 public immutable override decimals; uint256 public updatedAt; uint256 public startedAt;
    constructor(int256 a, uint8 d) { answer = a; decimals = d; updatedAt = block.timestamp; startedAt = block.timestamp; }
    function set(int256 a, uint256 u) external { answer = a; updatedAt = u; }
    function setStartedAt(uint256 s) external { startedAt = s; }
    function description() external pure returns (string memory) { return "MOCK / USD"; }
    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        return (1, answer, startedAt, updatedAt == 0 ? block.timestamp : updatedAt, 1);
    }
}

/// @notice Mimics UniversalRouter V3_SWAP_EXACT_IN (0x00). With payerIsUser=false the router pays from its own balance.
contract MockUniversalRouter is IUniversalRouter {
    mapping(address => mapping(address => uint256)) public rate; // out = in * rate / 1e18
    function setRate(address a, address b, uint256 r) external { rate[a][b] = r; }
    uint256 public gasBurn; // simulate gas-heavy swaps (griefing test)
    function setGasBurn(uint256 g) external { gasBurn = g; }

    function execute(bytes calldata commands, bytes[] calldata inputs, uint256 deadline) external payable {
        require(block.timestamp <= deadline, "TransactionDeadlinePassed");
        require(commands.length == 1 && uint8(commands[0]) == 0x00, "only V3_SWAP_EXACT_IN");
        (address recipient, uint256 amountIn, uint256 minOut, bytes memory path, bool payerIsUser) =
            abi.decode(inputs[0], (address, uint256, uint256, bytes, bool));
        require(!payerIsUser, "mock: payerIsUser unsupported");
        if (gasBurn > 0) { uint256 g0 = gasleft(); uint256 stop = g0 > gasBurn ? g0 - gasBurn : 0; while (gasleft() > stop) {} }
        address tIn; address tOut;
        assembly { tIn := shr(96, mload(add(path, 32))) tOut := shr(96, mload(add(add(path, 32), sub(mload(path), 20)))) }
        require(IERC20(tIn).balanceOf(address(this)) >= amountIn, "router: not funded"); // tokens must be pushed to the router first
        uint256 out = amountIn * rate[tIn][tOut] / 1e18;
        require(out >= minOut, "V3TooLittleReceived");
        IERC20(tOut).transfer(recipient, out);
    }
}

/// @notice Permit2 SignatureTransfer shape (no signature check; nonce/deadline/amount only).
contract MockPermit2 is ISignatureTransfer {
    mapping(address => mapping(uint256 => bool)) public used;
    function permitTransferFrom(
        PermitTransferFrom memory permit, SignatureTransferDetails calldata d, address owner, bytes calldata sig
    ) external {
        require(sig.length == 65, "sig");
        require(block.timestamp <= permit.deadline, "SignatureExpired");
        require(!used[owner][permit.nonce], "InvalidNonce");
        require(d.requestedAmount <= permit.permitted.amount, "InvalidAmount");
        used[owner][permit.nonce] = true;
        IERC20(permit.permitted.token).transferFrom(owner, d.to, d.requestedAmount);
    }
}

/// @notice CCTP V2 TokenMessenger (source). Emits messages in Circle's byte format.
contract MockTokenMessengerV2 is ITokenMessengerV2 {
    uint32 public immutable localDomain; uint256 public n;
    uint256 public minFee; // like Circle: units of 1/1e7 (1000 = 1 bp)
    event MessageSent(bytes message);
    constructor(uint32 d) { localDomain = d; }
    function setMinFee(uint256 f) external { minFee = f; }
    function getMinFeeAmount(uint256 amount) public view returns (uint256) { return amount * minFee / 1e7; }

    function depositForBurnWithHook(
        uint256 amount, uint32 dstDomain, bytes32 mintRecipient, address burnToken,
        bytes32 destCaller, uint256 maxFee, uint32 minFinality, bytes calldata hookData
    ) external {
        require(hookData.length > 0, "hook empty");
        require(maxFee < amount, "fee");
        require(maxFee >= getMinFeeAmount(amount), "maxFee < minFee");
        IERC20(burnToken).transferFrom(msg.sender, address(this), amount);
        MockERC20(burnToken).burnFrom_(address(this), amount);
        bytes memory body = abi.encodePacked(
            uint32(1), bytes32(uint256(uint160(burnToken))), mintRecipient, amount,
            bytes32(uint256(uint160(msg.sender))), maxFee, maxFee /* feeExecuted */, uint256(0), hookData
        );
        bytes memory message = abi.encodePacked(
            uint32(1), localDomain, dstDomain, bytes32(++n), bytes32(uint256(uint160(address(this)))),
            bytes32(0), destCaller, minFinality, minFinality, body
        );
        emit MessageSent(message);
    }
}

/// @notice CCTP V2 MessageTransmitter (destination). Checks caller/nonce and mints USDC.
contract MockMessageTransmitterV2 is IMessageTransmitterV2 {
    uint32 public immutable localDomain; MockERC20 public immutable usdc;
    mapping(bytes32 => bool) public usedNonce;
    constructor(uint32 d, address u) { localDomain = d; usdc = MockERC20(u); }

    function receiveMessage(bytes calldata m, bytes calldata) external returns (bool) {
        require(uint32(bytes4(m[8:12])) == localDomain, "wrong domain");
        bytes32 destCaller = bytes32(m[108:140]);
        require(destCaller == bytes32(0) || destCaller == bytes32(uint256(uint160(msg.sender))), "Invalid caller");
        bytes32 key = keccak256(abi.encode(bytes4(m[4:8]), bytes32(m[12:44])));
        require(!usedNonce[key], "Nonce already used");
        usedNonce[key] = true;
        bytes calldata b = m[148:];
        address to = address(uint160(uint256(bytes32(b[36:68]))));
        uint256 amount = uint256(bytes32(b[68:100]));
        uint256 fee = uint256(bytes32(b[164:196]));
        usdc.mint(to, amount - fee);
        return true;
    }
}

contract MockLzEndpoint {
    function compose(address from, address to, bytes32 guid, bytes calldata message) external {
        ILayerZeroComposer(to).lzCompose(from, guid, message, msg.sender, "");
    }
}

/// @notice Stargate V2 pool (IOFT). Source: lock + event. Destination: deliver() credits and composes.
contract MockStargatePool is IStargate {
    address public immutable override token; MockLzEndpoint public immutable endpoint;
    uint32 public immutable localEid; uint256 public feeBps; uint256 public nativeFee; uint64 public n;

    event Sent(bytes32 guid, uint32 dstEid, bytes32 to, uint256 amountReceived, address composeFrom, bytes composeMsg, bytes extraOptions);

    constructor(address t, address ep, uint32 eid, uint256 bps, uint256 fee) {
        token = t; endpoint = MockLzEndpoint(ep); localEid = eid; feeBps = bps; nativeFee = fee;
    }
    function setNativeFee(uint256 f) external { nativeFee = f; }

    function quoteOFT(SendParam calldata p) public view returns (OFTLimit memory, OFTFeeDetail[] memory, OFTReceipt memory) {
        uint256 recv = p.amountLD - p.amountLD * feeBps / 10_000;
        return (OFTLimit(0, type(uint256).max), new OFTFeeDetail[](0), OFTReceipt(p.amountLD, recv));
    }
    function quoteSend(SendParam calldata, bool) external view returns (MessagingFee memory) {
        return MessagingFee(nativeFee, 0);
    }
    function sendToken(SendParam calldata p, MessagingFee calldata f, address)
        external payable returns (MessagingReceipt memory r, OFTReceipt memory o, Ticket memory t)
    {
        require(msg.value >= f.nativeFee && f.nativeFee >= nativeFee, "fee");
        require(p.oftCmd.length == 0, "taxi only for compose");
        require(p.extraOptions.length > 0, "no compose gas");
        IERC20(token).transferFrom(msg.sender, address(this), p.amountLD);
        (, , o) = quoteOFT(p);
        require(o.amountReceivedLD >= p.minAmountLD, "slippage");
        r.guid = keccak256(abi.encode(localEid, ++n));
        r.nonce = n;
        emit Sent(r.guid, p.dstEid, p.to, o.amountReceivedLD, msg.sender, p.composeMsg, p.extraOptions);
        t;
    }

    /// @dev Test helper acting as the LayerZero executor on the destination chain.
    function deliver(bytes32 guid, uint32 srcEid, address to, uint256 amountLD, address composeFrom, bytes calldata composeMsg) external {
        MockERC20(token).mint(to, amountLD);
        bytes memory m = abi.encodePacked(uint64(1), srcEid, amountLD, bytes32(uint256(uint160(composeFrom))), composeMsg);
        endpoint.compose(address(this), to, guid, m);
    }
}

/// @notice QuoterV2.quoteExactInput using MockUniversalRouter rates (single hop).
contract MockQuoterV2 {
    MockUniversalRouter public immutable router;
    constructor(address r) { router = MockUniversalRouter(r); }
    function quoteExactInput(bytes memory path, uint256 amountIn)
        external view returns (uint256 amountOut, uint160[] memory a, uint32[] memory b, uint256 gasEstimate)
    {
        address tIn; address tOut;
        assembly { tIn := shr(96, mload(add(path, 32))) tOut := shr(96, mload(add(add(path, 32), sub(mload(path), 20)))) }
        amountOut = amountIn * router.rate(tIn, tOut) / 1e18;
        a; b; gasEstimate = 100_000;
    }
}

/// @notice FiatToken-like USDC for the real CCTP V2 contracts: minters mint (returns bool) and burn their own balance.
contract MockFiatToken is ERC20 {
    mapping(address => bool) public isMinter;
    constructor() ERC20("USD Coin", "USDC") {}
    function decimals() public pure override returns (uint8) { return 6; }
    function configureMinter(address m, bool ok) external { isMinter[m] = ok; }
    function mint(address to, uint256 a) external returns (bool) { require(isMinter[msg.sender], "not minter"); _mint(to, a); return true; }
    function burn(uint256 a) external { require(isMinter[msg.sender], "not minter"); _burn(msg.sender, a); }
    function faucet(address to, uint256 a) external { _mint(to, a); }
}

/// @notice Receiver that burns all gas on native transfers (griefing test).
contract GasGuzzler {
    receive() external payable { while (true) {} }
}

/// @notice Attack token: on every transfer it calls `target` with `data` (one level deep) and
///         bubbles the result, to prove that re-entering the hub is impossible.
contract ReentrantToken is ERC20 {
    address public callTarget; bytes public callData; bool private inside;
    bool public lastOk; bytes public lastRet;
    bool public bubble = true;
    constructor() ERC20("Evil", "EVIL") {}
    function mint(address to, uint256 a) external { _mint(to, a); }
    function arm(address t, bytes calldata d, bool bubbleRevert) external { callTarget = t; callData = d; bubble = bubbleRevert; }
    function _update(address from, address to, uint256 v) internal override {
        super._update(from, to, v);
        if (callTarget != address(0) && !inside) {
            inside = true;
            (bool ok, bytes memory r) = callTarget.call(callData);
            lastOk = ok; lastRet = r;
            inside = false;
            if (!ok && bubble) assembly { revert(add(r, 32), mload(r)) }
        }
    }
}

/// @notice Receiver that accepts native coin and returns ~180 KB of data (return-bomb test).
contract ReturnBomb {
    fallback() external payable { assembly { return(0, 180000) } }
}
