// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "./access/RegistryOwned.sol";
import "./access/FactoryInitializable.sol";

/**
 * @title SponsorshipPolicy
 * @notice Incentive policy of one chain. Every value is owner-configurable at any time
 *         ($500 / $20,000 / 0.5 % set at deploy time are just initial values).
 *
 *   All incentives are paid by the SOURCE chain vault, at swap time:
 *   - swap USD value >= minSponsorshipUsd8 -> every bridge fee is sponsored
 *       CCTP: Circle fee (capped, see below)
 *       Stargate: LayerZero native fee + Stargate token fee (recipient gets the full USDC amount)
 *   - swap USD value >= bonusThresholdUsd8 -> bonus = USDC amount * bonusBps / 10_000,
 *       capped at bonusMaxUsdc (0 = no cap), paid in USDC to the sender on the source chain.
 *       `bonusOncePerWallet` = true: each wallet receives the bonus only once.
 *
 *   Same-chain swaps (tokenIn -> USDC -> tokenOut): the same thresholds; eligible swaps get the
 *   Uniswap pool fees back (both legs, in USDC), at most `maxSwapFeeBps` of the USDC amount.
 *
 *   CCTP fee sponsorship cap: the vault never pays more than Circle's on-chain minFee plus
 *   `cctpFastFeeCapPpm` (parts per million of the amount) for a Fast transfer. The user picks
 *   `cctpMaxFee`, so without this cap an eligible user could make the vault "pay" a huge fee
 *   and receive the unused part (maxFee - feeExecuted) on the destination.
 *
 *   Deployed with CREATE2 (same address on every chain); values are set in `initialize`.
 *   USD values use 8 decimals ($500 = 500e8). `bonusMaxUsdc` is in local USDC units (18 dec on BSC).
 */
contract SponsorshipPolicy is RegistryOwned, FactoryInitializable {
    uint256 public minSponsorshipUsd8;   // fee sponsorship threshold
    uint256 public bonusThresholdUsd8;   // bonus threshold
    uint16  public bonusBps;             // bonus rate (50 = 0.5 %)
    uint256 public bonusMaxUsdc;         // bonus cap per swap (0 = no cap)
    bool    public bonusOncePerWallet;   // true: one bonus per wallet
    uint32  public cctpFastFeeCapPpm;    // max sponsored CCTP Fast fee (1 bp = 100 ppm)
    uint16  public maxSwapFeeBps;        // same-chain swaps: max Uniswap fee rebate (30 = 0.3 %)

    bool public feeCoverEnabled = true;
    bool public bonusEnabled = true;

    uint16 public constant MAX_BONUS_BPS = 500;          // hard cap 5 % (guards against typos)
    uint32 public constant MAX_CCTP_FEE_CAP_PPM = 2_000;  // hard cap 20 bps
    uint16 public constant MAX_SWAP_FEE_BPS = 100;        // hard cap 1 %

    event MinSponsorshipUpdated(uint256 oldUsd8, uint256 newUsd8);
    event BonusThresholdUpdated(uint256 oldUsd8, uint256 newUsd8);
    event BonusRateUpdated(uint16 bps, uint256 maxUsdc, bool oncePerWallet);
    event TogglesUpdated(bool feeCover, bool bonus);
    event CctpFastFeeCapUpdated(uint32 oldPpm, uint32 newPpm);
    event SwapFeeCapUpdated(uint16 bps);

    error Invalid(string reason);

    constructor(address registry) RegistryOwned(registry) {}

    function initialize(
        uint256 _minUsd8, uint256 _bonusThresholdUsd8,
        uint16 _bonusBps, uint256 _bonusMaxUsdc, bool _oncePerWallet, uint32 _cctpFeeCapPpm, uint16 _maxSwapFeeBps
    ) external initializer {
        _setThresholds(_minUsd8, _bonusThresholdUsd8);
        _setBonus(_bonusBps, _bonusMaxUsdc, _oncePerWallet);
        _setCctpCap(_cctpFeeCapPpm);
        _setSwapFeeCap(_maxSwapFeeBps);
    }

    // ---------------- Checks (called by the Hub) ----------------
    function isFeeEligible(uint256 usd8) external view returns (bool) {
        return initialized && feeCoverEnabled && usd8 >= minSponsorshipUsd8;
    }

    function isBonusEligible(uint256 usd8) external view returns (bool) {
        return initialized && bonusEnabled && usd8 >= bonusThresholdUsd8;
    }

    /// @notice Bonus for a swap that produced `usdcAmount` source USDC (eligibility checked separately).
    function bonusFor(uint256 usdcAmount) external view returns (uint256 amount) {
        amount = usdcAmount * bonusBps / 10_000;
        uint256 cap = bonusMaxUsdc;
        if (cap > 0 && amount > cap) amount = cap;
    }

    /// @notice Most the vault may pay for one CCTP burn of `amount` (`onchainMinFee` read by the Hub).
    function cctpSponsorCap(uint256 amount, uint256 onchainMinFee, bool fast) external view returns (uint256) {
        return onchainMinFee + (fast ? amount * cctpFastFeeCapPpm / 1_000_000 : 0);
    }

    /// @notice Whole-dollar thresholds for display.
    function thresholdsUsd() external view returns (uint256 sponsorshipUsd, uint256 bonusUsd) {
        return (minSponsorshipUsd8 / 1e8, bonusThresholdUsd8 / 1e8);
    }

    // ---------------- Owner ----------------

    /// @notice Fee sponsorship threshold in whole dollars (500 = $500).
    function setMinSponsorshipUsd(uint256 usd) external onlyOwner { _setThresholds(usd * 1e8, bonusThresholdUsd8); }

    /// @notice Bonus threshold in whole dollars (20000 = $20,000).
    function setBonusThresholdUsd(uint256 usd) external onlyOwner { _setThresholds(minSponsorshipUsd8, usd * 1e8); }

    /// @notice 8-decimal variants for sub-dollar precision.
    function setMinSponsorshipUsd8(uint256 usd8) external onlyOwner { _setThresholds(usd8, bonusThresholdUsd8); }
    function setBonusThresholdUsd8(uint256 usd8) external onlyOwner { _setThresholds(minSponsorshipUsd8, usd8); }

    /// @notice Bonus rate (bps of the swap's USDC), per-swap cap in local USDC units (0 = none), once-per-wallet rule.
    function setBonus(uint16 bps, uint256 maxUsdc, bool oncePerWallet) external onlyOwner { _setBonus(bps, maxUsdc, oncePerWallet); }

    /// @notice Set both thresholds at once (8-decimal USD).
    function setThresholds(uint256 minUsd8, uint256 bonusUsd8) external onlyOwner { _setThresholds(minUsd8, bonusUsd8); }

    /// @notice Max sponsored CCTP Fast fee on top of Circle's on-chain minFee (ppm, 100 = 1 bp).
    function setCctpFastFeeCapPpm(uint32 ppm) external onlyOwner { _setCctpCap(ppm); }

    /// @notice Same-chain swaps: most the vault refunds of the Uniswap pool fees, in bps of the USDC amount.
    function setSwapFeeCapBps(uint16 bps) external onlyOwner { _setSwapFeeCap(bps); }

    function setToggles(bool feeCover, bool bonus) external onlyOwner {
        feeCoverEnabled = feeCover; bonusEnabled = bonus;
        emit TogglesUpdated(feeCover, bonus);
    }

    // ---------------- Internal ----------------
    function _setThresholds(uint256 a, uint256 b) private {
        if (a == 0 || b <= a) revert Invalid("need 0 < min < bonus threshold");
        if (a != minSponsorshipUsd8) emit MinSponsorshipUpdated(minSponsorshipUsd8, a);
        if (b != bonusThresholdUsd8) emit BonusThresholdUpdated(bonusThresholdUsd8, b);
        minSponsorshipUsd8 = a; bonusThresholdUsd8 = b;
    }

    function _setBonus(uint16 bps, uint256 maxUsdc, bool once) private {
        if (bps > MAX_BONUS_BPS) revert Invalid("bonus > 5%");
        bonusBps = bps; bonusMaxUsdc = maxUsdc; bonusOncePerWallet = once;
        emit BonusRateUpdated(bps, maxUsdc, once);
    }

    function _setSwapFeeCap(uint16 bps) private {
        if (bps > MAX_SWAP_FEE_BPS) revert Invalid("swap fee cap > 1%");
        maxSwapFeeBps = bps;
        emit SwapFeeCapUpdated(bps);
    }

    function _setCctpCap(uint32 ppm) private {
        if (ppm > MAX_CCTP_FEE_CAP_PPM) revert Invalid("cctp cap > 20 bps");
        emit CctpFastFeeCapUpdated(cctpFastFeeCapPpm, ppm);
        cctpFastFeeCapPpm = ppm;
    }
}
