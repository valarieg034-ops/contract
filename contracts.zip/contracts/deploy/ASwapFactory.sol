// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title ASwapFactory
 * @notice CREATE2 factory that gives every ASwap contract the SAME address on every EVM chain.
 *
 *  The factory itself is deployed through the canonical deterministic deployment proxy
 *  (0x4e59b44847b379578588920cA78FbF26c0B4956C, present on all major EVM chains) with a fixed
 *  salt and no constructor arguments, so the factory has the same address everywhere too.
 *
 *  address = keccak256(0xff ++ factory ++ keccak256(deployer, salt) ++ keccak256(initCode))[12:]
 *
 *  Security
 *   - Permissioned salt: the CREATE2 salt is bound to `msg.sender`. Nobody but the original
 *     deployer key can ever obtain the ASwap addresses on a new chain (no address squatting,
 *     no impersonation of a trusted remote hub).
 *   - Atomic initialization: `initData` is called on the new contract in the same transaction,
 *     so there is no window in which someone else could initialize it.
 *   - The factory holds no funds and has no owner or upgrade path.
 */
contract ASwapFactory {
    event Deployed(address indexed deployer, bytes32 indexed salt, address indexed addr, bytes32 initCodeHash);

    error AlreadyDeployed(address addr);
    error DeployFailed();
    error InitFailed(bytes reason);

    /// @notice Deploy `initCode` with CREATE2 and optionally call `initData` on it, atomically.
    function deploy(bytes32 salt, bytes calldata initCode, bytes calldata initData) external returns (address addr) {
        bytes32 codeHash = keccak256(initCode);
        address predicted = computeAddress(msg.sender, salt, codeHash);
        if (predicted.code.length != 0) revert AlreadyDeployed(predicted);

        bytes32 s = guardedSalt(msg.sender, salt);
        bytes memory code = initCode;
        assembly { addr := create2(0, add(code, 0x20), mload(code), s) }
        if (addr == address(0) || addr != predicted) revert DeployFailed();

        if (initData.length > 0) {
            (bool ok, bytes memory ret) = addr.call(initData);
            if (!ok) revert InitFailed(ret);
        }
        emit Deployed(msg.sender, salt, addr, codeHash);
    }

    /// @notice The salt actually used by CREATE2: bound to the deployer account.
    function guardedSalt(address deployer, bytes32 salt) public pure returns (bytes32) {
        return keccak256(abi.encode(deployer, salt));
    }

    function computeAddress(address deployer, bytes32 salt, bytes32 initCodeHash) public view returns (address) {
        return address(uint160(uint256(keccak256(
            abi.encodePacked(bytes1(0xff), address(this), guardedSalt(deployer, salt), initCodeHash)
        ))));
    }
}
