// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice CCTP V2 message parser (Circle message format v1 / BurnMessageV2).
/// Header: version(4) srcDomain(4) dstDomain(4) nonce(32) sender(32) recipient(32) destCaller(32)
///         minFinality(4) finalityExecuted(4) | body(148~)
/// BurnMessageV2 body: version(4) burnToken(32) mintRecipient(32) amount(32) messageSender(32)
///         maxFee(32) feeExecuted(32) expirationBlock(32) | hookData(228~)
library CCTPMessage {
    uint256 internal constant BODY = 148;
    uint256 internal constant HOOK = 228;

    error Malformed();

    /// @dev bytes32 -> address, rejecting non-zero upper bytes (no truncation of non-EVM addresses).
    function toAddress(bytes32 x) internal pure returns (address) {
        if (uint256(x) >> 160 != 0) revert Malformed();
        return address(uint160(uint256(x)));
    }

    struct Burn {
        uint32  sourceDomain;
        bytes32 nonce;
        address mintRecipient;
        uint256 amount;
        address messageSender;
        uint256 feeExecuted;
    }

    function parse(bytes calldata m) internal pure returns (Burn memory b, bytes calldata hookData) {
        if (m.length < BODY + HOOK) revert Malformed();
        b.sourceDomain  = uint32(bytes4(m[4:8]));
        b.nonce         = bytes32(m[12:44]);
        bytes calldata body = m[BODY:];
        b.mintRecipient = toAddress(bytes32(body[36:68]));
        b.amount        = uint256(bytes32(body[68:100]));
        b.messageSender = toAddress(bytes32(body[100:132]));
        b.feeExecuted   = uint256(bytes32(body[164:196]));
        hookData        = body[HOOK:];
    }
}

/// @notice LayerZero OFTComposeMsgCodec layout.
/// nonce(8) srcEid(4) amountLD(32) composeFrom(32) | composeMsg(76~)
library OFTCompose {
    error Malformed();

    function parse(bytes calldata m)
        internal pure returns (uint32 srcEid, uint256 amountLD, address composeFrom, bytes calldata composeMsg)
    {
        if (m.length < 76) revert Malformed();
        srcEid      = uint32(bytes4(m[8:12]));
        amountLD    = uint256(bytes32(m[12:44]));
        composeFrom = CCTPMessage.toAddress(bytes32(m[44:76]));
        composeMsg  = m[76:];
    }
}

/// @notice LayerZero V2 Type3 options: lzCompose(index 0, gas)
/// = OptionsBuilder.newOptions().addExecutorLzComposeOption(0, gas, 0)
library LzOptions {
    function compose(uint128 gas) internal pure returns (bytes memory) {
        return abi.encodePacked(uint16(3), uint8(1), uint16(19), uint8(3), uint16(0), gas);
    }
}

/// @notice Uniswap V3 path: token(20) | fee(3) | token(20) | ...
library V3Path {
    error BadPath();

    function check(bytes memory path, address tokenIn, address tokenOut) internal pure {
        uint256 len = path.length;
        if (len < 43 || (len - 20) % 23 != 0) revert BadPath();
        address first; address last;
        assembly {
            first := shr(96, mload(add(path, 32)))
            last  := shr(96, mload(add(add(path, 32), sub(len, 20))))
        }
        if (first != tokenIn || last != tokenOut) revert BadPath();
    }
}
