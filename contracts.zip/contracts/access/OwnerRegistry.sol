// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";
import "./FactoryInitializable.sol";

/**
 * @title OwnerRegistry
 * @notice Per-chain list of owners. Every other contract on the same chain (Hub, ASwapVault,
 *         PriceOracle, SponsorshipPolicy, ChainConfig) asks this registry who may call its
 *         `onlyOwner` functions. Adding or removing an owner here applies to all of them.
 *
 *  Deployed with CREATE2 at the same address on every chain; the initial owners are set in
 *  `initialize` (not the constructor) so the address does not depend on the owner list.
 *  Each chain keeps its own owner list.
 *
 *  - Any number of owners (EOAs or multisigs such as Safe).
 *  - All owners have equal power, including adding/removing other owners.
 *  - The last owner can never be removed, so the system cannot become ownerless.
 */
contract OwnerRegistry is FactoryInitializable {
    using EnumerableSet for EnumerableSet.AddressSet;

    EnumerableSet.AddressSet private _owners;

    event OwnerAdded(address indexed owner, address indexed by);
    event OwnerRemoved(address indexed owner, address indexed by);

    error NotOwner(address caller);
    error ZeroAddress();
    error AlreadyOwner(address account);
    error NotAnOwner(address account);
    error CannotRemoveLastOwner();

    modifier onlyOwner() {
        if (!_owners.contains(msg.sender)) revert NotOwner(msg.sender);
        _;
    }

    function initialize(address[] calldata initialOwners) external initializer {
        if (initialOwners.length == 0) revert CannotRemoveLastOwner();
        for (uint256 i = 0; i < initialOwners.length; i++) _add(initialOwners[i], msg.sender);
    }

    /// @notice Add a new owner.
    function addOwner(address account) external onlyOwner { _add(account, msg.sender); }

    /// @notice Remove an owner (self-removal allowed, except for the last owner).
    function removeOwner(address account) external onlyOwner { _remove(account, msg.sender); }

    /// @notice Atomically replace `oldOwner` with `newOwner`.
    function replaceOwner(address oldOwner, address newOwner) external onlyOwner {
        _add(newOwner, msg.sender);
        _remove(oldOwner, msg.sender);
    }

    function isOwner(address account) external view returns (bool) { return _owners.contains(account); }
    function owners() external view returns (address[] memory) { return _owners.values(); }
    function ownerCount() external view returns (uint256) { return _owners.length(); }

    function _add(address account, address by) private {
        if (account == address(0)) revert ZeroAddress();
        if (!_owners.add(account)) revert AlreadyOwner(account);
        emit OwnerAdded(account, by);
    }

    function _remove(address account, address by) private {
        if (_owners.length() == 1) revert CannotRemoveLastOwner();
        if (!_owners.remove(account)) revert NotAnOwner(account);
        emit OwnerRemoved(account, by);
    }
}
