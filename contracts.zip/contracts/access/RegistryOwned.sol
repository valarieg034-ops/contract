// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IOwnerRegistry {
    function isOwner(address account) external view returns (bool);
}

/**
 * @title RegistryOwned
 * @notice Base contract: `onlyOwner` is decided by the chain's OwnerRegistry.
 */
abstract contract RegistryOwned {
    IOwnerRegistry public immutable ownerRegistry;

    error NotOwner(address caller);
    error ZeroAddress();

    constructor(address registry) {
        if (registry == address(0) || registry.code.length == 0) revert ZeroAddress();
        ownerRegistry = IOwnerRegistry(registry);
    }

    modifier onlyOwner() {
        if (!ownerRegistry.isOwner(msg.sender)) revert NotOwner(msg.sender);
        _;
    }
}
