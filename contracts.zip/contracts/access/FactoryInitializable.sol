// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title FactoryInitializable
 * @notice One-shot initializer for contracts deployed with CREATE2 at the same address on every chain.
 *
 *  Same address on every chain requires the same init code, so constructors take no chain-specific
 *  arguments. Chain-specific values (USDC address, limits, bridges ...) are set in `initialize`.
 *
 *  `initialize` can only be called once and only by the account that deployed the contract
 *  (the ASwapFactory, which calls it in the same transaction as CREATE2). This closes the
 *  classic "front-run the initializer" attack on deterministic deployments.
 */
abstract contract FactoryInitializable {
    address private immutable _initializer;
    bool public initialized;

    error AlreadyInitialized();
    error NotInitializer();
    error NotInitialized();

    constructor() { _initializer = msg.sender; }

    modifier initializer() {
        if (msg.sender != _initializer) revert NotInitializer();
        if (initialized) revert AlreadyInitialized();
        initialized = true;
        _;
    }

    modifier whenInitialized() {
        if (!initialized) revert NotInitialized();
        _;
    }
}
