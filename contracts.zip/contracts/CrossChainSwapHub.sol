// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/utils/Pausable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./access/RegistryOwned.sol";
import "./access/FactoryInitializable.sol";
import "./interfaces/IExternal.sol";
import "./libraries/Codec.sol";
import "./ChainConfig.sol";
import "./ASwapVault.sol";
import "./PriceOracle.sol";
import "./SponsorshipPolicy.sol";

/**
 * @title CrossChainSwapHub
 * @notice Deployed with identical code AT THE SAME ADDRESS on every chain (CREATE2 via ASwapFactory).
 *         One contract handles both legs. Chain-specific values are set once in `initialize`.
 *
 *  Security
 *    - Sender authentication: CCTP `messageSender` / Stargate `composeFrom` must equal the hub
 *      registered in ChainConfig for the source chain.
 *    - CCTP destinationCaller = destination hub, so nobody else can consume the message.
 *    - Replay protection, reentrancy guard, pausable, fixed gas budget for the destination swap.
 */
contract CrossChainSwapHub is RegistryOwned, FactoryInitializable, Pausable, ReentrancyGuard, ILayerZeroComposer {
    using SafeERC20 for IERC20;

    // =====================================================================
    // Types
    // =====================================================================
    enum Route { AUTO, CCTP, STARGATE }

    /// @notice What to do on the destination chain. Travels inside the bridge message.
    struct Delivery {
        address recipient;      // final receiver
        address tokenOut;       // token to receive (destination chain address)
        bytes   dstPath;        // Uniswap V3 path: dstUSDC -> ... -> tokenOut (empty when tokenOut is USDC)
        uint256 minAmountOut;   // minimum output of the destination swap
        bool    unwrapToNative; // deliver native coin when tokenOut is the wrapped native token
        uint64  deadline;       // after this time the recipient gets USDC instead of a swap
    }

    /// @notice What actually travels in the bridge message. `expectedUsdc` is set by the source hub
    ///         (never by the user): the USDC the user swapped, in destination decimals. Anything that
    ///         arrives above it is unused sponsorship (CCTP maxFee - feeExecuted, rounding) and goes back
    ///         to the destination vault instead of the recipient.
    struct Envelope {
        Delivery d;
        uint256  expectedUsdc;
    }

    struct SwapParams {
        address tokenIn;        // ERC20 address, or address(0) for the native coin
        uint256 amountIn;
        bytes   srcPath;        // tokenIn (or wrapped native) -> ... -> srcUSDC (empty when tokenIn is USDC)
        uint256 minUsdcOut;     // minimum USDC from the source swap
        uint256 dstChainId;
        Route   route;          // AUTO: CCTP when both chains support it, otherwise Stargate
        bool    fastCCTP;       // true: Fast (~8-20 s, small fee), false: Standard (free)
        uint256 cctpMaxFee;     // CCTP fee cap in USDC units (Fast fee, and Circle's on-chain minFee for any burn)
        uint256 maxNativeFee;   // user's consent cap for the Stargate fee when it is not sponsored
        Delivery delivery;
    }

    /// @notice Same-chain swap: tokenIn -> USDC -> tokenOut (USDC is always the middle coin).
    struct LocalSwapParams {
        address tokenIn;        // ERC20 address, or address(0) for the native coin
        uint256 amountIn;
        bytes   pathIn;         // tokenIn (or wrapped native) -> ... -> USDC (empty when tokenIn is USDC)
        uint256 minUsdcOut;     // minimum USDC from the first leg
        address tokenOut;       // ERC20 to receive (wrapped native + unwrapToNative for the native coin)
        bytes   pathOut;        // USDC -> ... -> tokenOut (empty when tokenOut is USDC)
        uint256 minAmountOut;   // minimum final output
        address recipient;
        bool    unwrapToNative;
        uint64  deadline;
    }

    /// @notice Permit2 SignatureTransfer data. Empty signature = plain `transferFrom` (prior approve).
    struct PermitData { uint256 nonce; uint256 deadline; bytes signature; }

    struct Init {
        uint256 localChainId;
        address config; address vault; address oracle; address policy;
        address permit2; address tokenMessenger; address messageTransmitter; address lzEndpoint;
    }

    // =====================================================================
    // State
    // =====================================================================
    uint256 public localChainId;

    ChainConfig       public config;
    ASwapVault        public vault;
    PriceOracle       public oracle;
    SponsorshipPolicy public policy;

    ISignatureTransfer    public permit2;
    ITokenMessengerV2     public tokenMessenger;
    IMessageTransmitterV2 public messageTransmitter;
    address               public lzEndpoint;

    /// @notice Native coin marker for `SwapParams.tokenIn` and in events.
    address public constant NATIVE = address(0);

    /// @notice Gas forwarded to the destination swap (owner adjustable).
    ///         Keep `lzComposeGas` at least ~400k above this value.
    uint256 public swapGas = 800_000;
    uint256 internal constant POST_SWAP_GAS = 120_000; // payout + events after the swap
    /// @notice Max Uniswap V3 path length: 4 hops (20 + 4 * 23 bytes). Bounds the LayerZero fee
    ///         (paid by the vault when sponsored) and destination gas.
    uint256 public constant MAX_PATH_LENGTH = 112;
    /// @notice Gas given to a native-coin recipient; a contract that burns all gas cannot block delivery.
    uint256 internal constant NATIVE_PAYOUT_GAS = 100_000;

    uint256 public swapNonce;
    mapping(bytes32 => bool) public processed;
    /// @notice Payouts that could not be transferred (e.g. blacklisted recipient). Claim via claimUnclaimed.
    mapping(address => mapping(address => uint256)) public unclaimed;
    /// @notice Sum of `unclaimed` per token. Owners can never rescue these user funds.
    mapping(address => uint256) public unclaimedTotal;

    // =====================================================================
    // Events / errors
    // =====================================================================
    event SwapInitiated(
        bytes32 indexed transferId, address indexed sender, uint256 indexed dstChainId,
        address tokenIn, uint256 amountIn, uint256 usdcBridged,
        bool viaCCTP, bool feeSponsored, bool bonusPaid,
        address recipient, address tokenOut
    );
    event Delivered(
        bytes32 indexed id, uint256 indexed srcChainId, address indexed recipient,
        address tokenOut, uint256 bridgedUsdc, uint256 amountOut, bool swapped
    );
    event PayoutDeferred(address indexed recipient, address indexed token, uint256 amount);
    event LocalSwap(
        bytes32 indexed id, address indexed sender, address indexed recipient,
        address tokenIn, uint256 amountIn, uint256 usdcAmount, uint256 swapFeeRebate,
        address tokenOut, uint256 amountOut, bool bonusPaid
    );
    /// @notice Unused fee sponsorship that reached the destination, returned to this chain's vault.
    event SurplusReturned(bytes32 indexed id, uint256 amount);
    event ComponentsSet(address config, address vault, address oracle, address policy);
    event BridgesSet(address permit2, address tokenMessenger, address messageTransmitter, address lzEndpoint);
    event Rescued(address indexed token, address indexed to, uint256 amount);
    event SwapGasSet(uint256 gas);
    /// @notice An incentive was due but the vault could not pay it; the swap continued.
    ///   kind 1 = LayerZero native fee (paid by the user from msg.value)
    ///   kind 2 = CCTP Fast fee (deducted from the user's USDC)
    ///   kind 3 = bonus not paid (vault empty / daily cap / error)
    ///   kind 4 = Stargate token fee (deducted from the bridged USDC)
    ///   kind 5 = Uniswap pool fees of a same-chain swap (not refunded)
    event SponsorshipUnavailable(address indexed user, uint8 indexed kind, uint256 amount);

    error InvalidParams();
    error UnsupportedChain();
    error UnsupportedRoute();
    error Expired();
    error Slippage();
    error FeeTooHigh();
    /// @notice The user has to pay the fee but sent too little (`budget`) or consented to less (`maxConsent`).
    error FeeNotCovered(uint256 required, uint256 budget, uint256 maxConsent);
    error Unauthorized();
    error UntrustedSender();
    error AlreadyProcessed();
    error NativeTransferFailed();
    error InsufficientGas();

    // =====================================================================
    // Constructor
    // =====================================================================
    constructor(address registry) RegistryOwned(registry) {}

    /// @notice One-shot setup, called by ASwapFactory in the deployment transaction.
    function initialize(Init calldata i) external initializer {
        if (i.localChainId == 0) revert InvalidParams();
        localChainId = i.localChainId;
        _setComponents(i.config, i.vault, i.oracle, i.policy);
        _setBridges(i.permit2, i.tokenMessenger, i.messageTransmitter, i.lzEndpoint);
    }

    /// @dev Receives sponsored fees from the vault and native coin from WETH.withdraw().
    receive() external payable {}

    // =====================================================================
    // 1. Source chain: swap (single user entry point)
    // =====================================================================

    /**
     * @notice Swap `amountIn` of `tokenIn` on this chain into `delivery.tokenOut` on `dstChainId`.
     * @dev Native coin: set `tokenIn = address(0)` and send `msg.value = amountIn + fee budget`.
     *      ERC20: pass a Permit2 signature (or an empty signature after a plain approve);
     *      `msg.value` is only the fee budget.
     *      Any unused fee budget is refunded. If the fee is not sponsored and the budget or the
     *      consent cap is too low, the whole call reverts and the user's tokens never move.
     */
    function swap(SwapParams calldata p, PermitData calldata permit)
        external payable nonReentrant whenNotPaused returns (bytes32)
    {
        ChainConfig.ChainParams memory src = config.getChain(localChainId);
        ChainConfig.ChainParams memory dst = config.getChain(p.dstChainId);

        bool native = p.tokenIn == NATIVE;
        address tokenIn = native ? src.wrappedNative : p.tokenIn;
        _validate(p, tokenIn, src, dst);

        uint256 received;
        uint256 feeBudget;
        if (native) {
            if (tokenIn == address(0) || msg.value < p.amountIn) revert InvalidParams();
            IWETH(tokenIn).deposit{value: p.amountIn}();
            received = p.amountIn;
            feeBudget = msg.value - p.amountIn;
        } else {
            received = _pull(tokenIn, p.amountIn, permit); // balance delta: safe for fee-on-transfer tokens
            feeBudget = msg.value;
        }
        return _execute(p, tokenIn, src, dst, received, feeBudget);
    }

    function _execute(
        SwapParams calldata p,
        address tokenIn,
        ChainConfig.ChainParams memory src,
        ChainConfig.ChainParams memory dst,
        uint256 received,
        uint256 nativeBudget // native available for fees; the rest is refunded
    ) internal returns (bytes32 transferId) {
        // source swap: tokenIn -> USDC
        uint256 usdcAmt = tokenIn == src.usdc
            ? received
            : _swapExactIn(src.uniswapRouter, tokenIn, src.usdc, p.srcPath, received, p.minUsdcOut);

        // eligibility: USD value of the USDC actually obtained vs owner-set thresholds
        (bool priced, uint256 usd8) = oracle.tryUsdValue(src.usdc, usdcAmt);
        bool feeEligible = priced && policy.isFeeEligible(usd8);
        bool bonusEligible = priced && policy.isBonusEligible(usd8);

        // bridge
        bool viaCCTP = _useCCTP(p.route, src, dst);
        bytes memory payload = _payload(p.delivery, usdcAmt, src, dst);
        bool sponsored;
        uint256 userNativeSpent;
        if (viaCCTP) {
            (transferId, sponsored) = _sendCCTP(src, dst, usdcAmt, p.fastCCTP, p.cctpMaxFee, payload, feeEligible);
        } else {
            (transferId, sponsored, userNativeSpent) =
                _sendStargate(src, dst, usdcAmt, p.maxNativeFee, nativeBudget, payload, feeEligible);
        }

        bool bonusPaid = _payBonus(bonusEligible, usdcAmt);

        emit SwapInitiated(
            transferId, msg.sender, p.dstChainId, p.tokenIn, p.amountIn, usdcAmt,
            viaCCTP, sponsored, bonusPaid, p.delivery.recipient, p.delivery.tokenOut
        );

        // refund unused native
        uint256 refund = nativeBudget - userNativeSpent;
        if (refund > 0) {
            (bool ok, ) = payable(msg.sender).call{value: refund}("");
            if (!ok) revert NativeTransferFailed();
        }
    }

    // =====================================================================
    // 1b. Same chain: tokenIn -> USDC -> tokenOut
    // =====================================================================

    /**
     * @notice Swap on this chain with USDC as the middle coin, in one transaction.
     * @dev Native input: `tokenIn = address(0)`, `msg.value >= amountIn` (the rest is refunded).
     *      Eligible (>= sponsorship threshold): the vault adds the Uniswap pool fees of both legs in USDC
     *      before the second leg (capped at `policy.maxSwapFeeBps`). Bonus as for cross-chain swaps.
     *      Any failure (slippage, deadline, bad path) reverts everything: the user keeps the tokens.
     */
    function swapLocal(LocalSwapParams calldata p, PermitData calldata permit)
        external payable nonReentrant whenNotPaused returns (uint256 amountOut)
    {
        ChainConfig.ChainParams memory c = config.getChain(localChainId);
        if (!c.enabled || c.usdc == address(0)) revert UnsupportedChain();
        bool nativeIn = p.tokenIn == NATIVE;
        address tIn = nativeIn ? c.wrappedNative : p.tokenIn;
        _validateLocal(p, tIn, c);

        // 1) input
        uint256 received;
        if (nativeIn) {
            if (msg.value < p.amountIn) revert InvalidParams();
            IWETH(tIn).deposit{value: p.amountIn}();
            received = p.amountIn;
        } else {
            received = _pull(tIn, p.amountIn, permit);
        }

        // 2) first leg: tokenIn -> USDC
        uint256 usdcAmt = tIn == c.usdc ? received : _swapExactIn(c.uniswapRouter, tIn, c.usdc, p.pathIn, received, p.minUsdcOut);

        // 3) eligibility (same thresholds as cross-chain)
        (bool priced, uint256 usd8) = oracle.tryUsdValue(c.usdc, usdcAmt);
        bool feeEligible = priced && policy.isFeeEligible(usd8);
        bool bonusEligible = priced && policy.isBonusEligible(usd8);

        // 4) Uniswap fee sponsorship: the vault adds the pool fees (both legs) in USDC
        uint256 rebate;
        if (feeEligible) {
            uint256 r = _swapFeeRebate(usdcAmt, tIn == c.usdc ? new bytes(0) : p.pathIn, p.pathOut);
            if (r > 0) {
                try vault.payUsdc(r) { rebate = r; }
                catch { emit SponsorshipUnavailable(msg.sender, 5, r); } // vault empty: swap continues without it
            }
        }
        uint256 total = usdcAmt + rebate;

        // 5) second leg: USDC -> tokenOut
        amountOut = p.tokenOut == c.usdc
            ? total
            : _swapExactIn(c.uniswapRouter, c.usdc, p.tokenOut, p.pathOut, total, p.minAmountOut);
        if (amountOut < p.minAmountOut) revert Slippage();

        // 6) bonus to the sender, 7) payout to the recipient
        bool bonusPaid = _payBonus(bonusEligible, usdcAmt);
        _payout(c.wrappedNative, p.tokenOut, p.recipient, amountOut, p.unwrapToNative);
        emit LocalSwap(
            keccak256(abi.encode(localChainId, address(this), ++swapNonce)), msg.sender, p.recipient,
            p.tokenIn, p.amountIn, usdcAmt, rebate, p.tokenOut, amountOut, bonusPaid
        );

        // refund extra native
        uint256 refund = msg.value - (nativeIn ? p.amountIn : 0);
        if (refund > 0) {
            (bool ok, ) = payable(msg.sender).call{value: refund}("");
            if (!ok) revert NativeTransferFailed();
        }
    }

    // =====================================================================
    // 2. Destination chain: CCTP (relayer or user)
    // =====================================================================
    function relayCCTP(bytes calldata message, bytes calldata attestation) external nonReentrant whenNotPaused {
        (CCTPMessage.Burn memory b, bytes calldata hook) = CCTPMessage.parse(message);
        if (b.mintRecipient != address(this)) revert Unauthorized();

        // destinationCaller = this contract, so minting is only possible through this function.
        // The delivered amount is the USDC actually minted (balance delta), never a number from the message.
        IERC20 localUsdc = IERC20(config.getChain(localChainId).usdc);
        uint256 before = localUsdc.balanceOf(address(this));
        if (!messageTransmitter.receiveMessage(message, attestation)) revert Unauthorized();
        uint256 minted = localUsdc.balanceOf(address(this)) - before;

        uint256 srcChainId = config.domainToChainId(b.sourceDomain);
        _checkRemoteHub(srcChainId, b.messageSender);

        Envelope memory e = abi.decode(hook, (Envelope));
        bytes32 id = keccak256(abi.encode(uint8(1), b.sourceDomain, b.nonce));
        _deliver(id, srcChainId, e, minted);
    }

    // =====================================================================
    // 3. Destination chain: Stargate (called by the LayerZero executor)
    // =====================================================================
    function lzCompose(address from, bytes32 guid, bytes calldata message, address, bytes calldata)
        external payable override nonReentrant whenNotPaused
    {
        ChainConfig.ChainParams memory local = config.getChain(localChainId);
        if (msg.sender != lzEndpoint || from != local.stargatePool || from == address(0)) revert Unauthorized();

        (uint32 srcEid, uint256 amountLD, address composeFrom, bytes calldata composeMsg) = OFTCompose.parse(message);
        uint256 srcChainId = config.eidToChainId(srcEid);
        _checkRemoteHub(srcChainId, composeFrom);

        Envelope memory e = abi.decode(composeMsg, (Envelope));
        _deliver(guid, srcChainId, e, amountLD);
    }

    /// @dev Self-call wrapper so a failed swap (including the token push) is rolled back by try/catch.
    function executeSwap(address router, address tIn, address tOut, bytes calldata path, uint256 amountIn, uint256 minOut)
        external returns (uint256)
    {
        if (msg.sender != address(this)) revert Unauthorized();
        return _swapExactIn(router, tIn, tOut, path, amountIn, minOut);
    }

    /// @notice Withdraw a deferred payout to any address of the recipient's choice.
    function claimUnclaimed(address token, address to) external nonReentrant {
        uint256 amt = unclaimed[msg.sender][token];
        if (amt == 0 || to == address(0)) revert InvalidParams();
        unclaimed[msg.sender][token] = 0;
        unclaimedTotal[token] -= amt;
        IERC20(token).safeTransfer(to, amt);
    }

    // =====================================================================
    // 4. Views (used by the SDK)
    // =====================================================================
    function quoteEligibility(address user, uint256 usdcAmount) external view returns (
        bool priced, uint256 usd8, bool feeEligible, bool bonusEligible,
        uint256 bonusAmount, bool bonusClaimed, uint256 bonusAvailable,
        uint256 vaultNativeAvailable, uint256 vaultUsdcAvailable
    ) {
        address usdc = config.getChain(localChainId).usdc;
        (priced, usd8) = oracle.tryUsdValue(usdc, usdcAmount);
        feeEligible = priced && policy.isFeeEligible(usd8);
        bonusEligible = priced && policy.isBonusEligible(usd8);
        bonusAmount = bonusEligible ? policy.bonusFor(usdcAmount) : 0;
        bonusClaimed = vault.isClaimed(user);
        bonusAvailable = vault.availableBonus();
        vaultNativeAvailable = vault.availableNative();
        vaultUsdcAvailable = vault.availableUsdc();
    }

    /// @notice Stargate quote. `tokenFee` = USDC the vault adds so the destination receives `usdcAmount`
    ///         in full (0 when there is no fee or it cannot be grossed up). With `sponsorTokenFee` the
    ///         native fee and `amountReceived` are quoted for the grossed-up send.
    function quoteStargate(uint256 dstChainId, uint256 usdcAmount, Delivery calldata d, bool sponsorTokenFee)
        external view returns (uint256 nativeFee, uint256 amountReceived, uint256 tokenFee)
    {
        ChainConfig.ChainParams memory src = config.getChain(localChainId);
        ChainConfig.ChainParams memory dst = config.getChain(dstChainId);
        if (src.stargatePool == address(0) || dst.lzEid == 0) revert UnsupportedRoute();
        IStargate sg = IStargate(src.stargatePool);
        SendParam memory sp = _sendParam(dst, usdcAmount, _payload(d, usdcAmount, src, dst));
        (tokenFee, ) = _stargateTokenFee(sg, sp, usdcAmount);
        if (sponsorTokenFee) sp.amountLD = usdcAmount + tokenFee;
        (, , OFTReceipt memory r) = sg.quoteOFT(sp);
        sp.minAmountLD = r.amountReceivedLD;
        nativeFee = sg.quoteSend(sp, false).nativeFee;
        amountReceived = r.amountReceivedLD;
    }

    /// @notice USDC the vault adds to a same-chain swap of `usdcAmount` (before availability checks).
    function quoteSwapFeeRebate(uint256 usdcAmount, bytes calldata pathIn, bytes calldata pathOut) external view returns (uint256) {
        return _swapFeeRebate(usdcAmount, pathIn, pathOut);
    }

    function willUseCCTP(uint256 dstChainId, Route route) external view returns (bool) {
        return _useCCTP(route, config.getChain(localChainId), config.getChain(dstChainId));
    }

    // =====================================================================
    // 5. Owner
    // =====================================================================
    function setComponents(address c, address v, address o, address pol) external onlyOwner {
        _setComponents(c, v, o, pol);
    }

    function setBridges(address p2, address tm, address mt, address ep) external onlyOwner {
        _setBridges(p2, tm, mt, ep);
    }

    function setSwapGas(uint256 g) external onlyOwner {
        if (g < 100_000 || g > 15_000_000) revert InvalidParams();
        swapGas = g;
        emit SwapGasSet(g);
    }

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    /// @notice Recover tokens sent here by mistake. Deferred user payouts (`unclaimedTotal`) are untouchable.
    function rescueToken(address token, address to, uint256 amount) external onlyOwner {
        if (IERC20(token).balanceOf(address(this)) < amount + unclaimedTotal[token]) revert InvalidParams();
        IERC20(token).safeTransfer(to, amount);
        emit Rescued(token, to, amount);
    }

    function rescueNative(address payable to, uint256 amount) external onlyOwner {
        (bool ok, ) = to.call{value: amount}("");
        if (!ok) revert NativeTransferFailed();
        emit Rescued(address(0), to, amount);
    }

    // =====================================================================
    // Internal: source
    // =====================================================================
    function _validate(
        SwapParams calldata p, address tokenIn, ChainConfig.ChainParams memory src, ChainConfig.ChainParams memory dst
    ) internal view {
        if (!src.enabled || src.usdc == address(0)) revert UnsupportedChain();
        if (p.dstChainId == localChainId || !dst.enabled || dst.hub == address(0)) revert UnsupportedChain();
        if (p.amountIn == 0 || p.delivery.recipient == address(0)) revert InvalidParams();
        if (p.delivery.deadline < block.timestamp) revert Expired();
        if (tokenIn != src.usdc && p.minUsdcOut == 0) revert InvalidParams(); // sandwich protection
        if (p.srcPath.length > MAX_PATH_LENGTH || p.delivery.dstPath.length > MAX_PATH_LENGTH) revert InvalidParams();
        if (p.delivery.tokenOut == dst.usdc) {
            if (p.delivery.dstPath.length != 0) revert InvalidParams(); // no padding of the bridge payload
        } else {
            if (p.delivery.minAmountOut == 0) revert InvalidParams();
            V3Path.check(p.delivery.dstPath, dst.usdc, p.delivery.tokenOut);
        }
    }

    function _validateLocal(LocalSwapParams calldata p, address tIn, ChainConfig.ChainParams memory c) internal view {
        if (p.amountIn == 0 || p.recipient == address(0) || tIn == address(0)) revert InvalidParams();
        if (p.deadline < block.timestamp) revert Expired();
        if (p.pathIn.length > MAX_PATH_LENGTH || p.pathOut.length > MAX_PATH_LENGTH) revert InvalidParams();
        // no round trips (A -> USDC -> A): they would only collect the fee rebate and the bonus
        if (tIn == p.tokenOut) revert InvalidParams();
        if (tIn == c.usdc) { if (p.pathIn.length != 0) revert InvalidParams(); }
        else if (p.minUsdcOut == 0) revert InvalidParams(); // sandwich protection
        if (p.tokenOut == c.usdc) { if (p.pathOut.length != 0) revert InvalidParams(); }
        else {
            if (p.minAmountOut == 0) revert InvalidParams();
            V3Path.check(p.pathOut, c.usdc, p.tokenOut);
        }
    }

    /// @dev Pool fees of both legs in USDC terms, capped at policy.maxSwapFeeBps of the USDC amount.
    ///      Leg 1 fee is taken from the input side: usdc * f / (1 - f). Leg 2 fee: usdc * f.
    function _swapFeeRebate(uint256 usdcAmt, bytes memory pathIn, bytes memory pathOut) internal view returns (uint256 r) {
        uint256 fIn = _pathFeePpm(pathIn);
        uint256 fOut = _pathFeePpm(pathOut);
        if (fIn > 0 && fIn < 1_000_000) r = usdcAmt * fIn / (1_000_000 - fIn);
        r += usdcAmt * fOut / 1_000_000;
        uint256 cap = usdcAmt * policy.maxSwapFeeBps() / 10_000;
        if (r > cap) r = cap;
    }

    /// @dev Sum of the Uniswap V3 fee tiers in a path (parts per million, 500 = 0.05 %).
    function _pathFeePpm(bytes memory path) internal pure returns (uint256 sum) {
        uint256 len = path.length;
        if (len < 43) return 0;
        for (uint256 o = 20; o + 23 <= len; o += 23) {
            uint256 f;
            assembly { f := shr(232, mload(add(add(path, 32), o))) }
            sum += f;
        }
    }

    /// @dev Bonus: % of the swap's USDC, paid to the sender on THIS chain by THIS chain's vault.
    ///      Never blocks the swap.
    function _payBonus(bool eligible, uint256 usdcAmt) internal returns (bool paid) {
        if (!eligible) return false;
        uint256 bonusAmt = policy.bonusFor(usdcAmt);
        if (bonusAmt == 0) return false;
        bool once = policy.bonusOncePerWallet();
        bool skipByRule = once && vault.isClaimed(msg.sender);
        try vault.payBonus(msg.sender, bonusAmt, once) returns (bool ok) { paid = ok; } catch {}
        if (!paid && !skipByRule) emit SponsorshipUnavailable(msg.sender, 3, bonusAmt);
    }

    function _pull(address token, uint256 amount, PermitData calldata permit) internal returns (uint256) {
        uint256 before = IERC20(token).balanceOf(address(this));
        if (permit.signature.length > 0) {
            permit2.permitTransferFrom(
                ISignatureTransfer.PermitTransferFrom({
                    permitted: ISignatureTransfer.TokenPermissions({token: token, amount: amount}),
                    nonce: permit.nonce,
                    deadline: permit.deadline
                }),
                ISignatureTransfer.SignatureTransferDetails({to: address(this), requestedAmount: amount}),
                msg.sender,
                permit.signature
            );
        } else {
            IERC20(token).safeTransferFrom(msg.sender, address(this), amount);
        }
        return IERC20(token).balanceOf(address(this)) - before;
    }

    function _useCCTP(Route route, ChainConfig.ChainParams memory src, ChainConfig.ChainParams memory dst)
        internal pure returns (bool)
    {
        bool cctpOk = src.cctpEnabled && dst.cctpEnabled;
        bool sgOk = src.stargatePool != address(0) && dst.lzEid != 0;
        if (route == Route.CCTP) { if (!cctpOk) revert UnsupportedRoute(); return true; }
        if (route == Route.STARGATE) { if (!sgOk) revert UnsupportedRoute(); return false; }
        if (cctpOk) return true;
        if (sgOk) return false;
        revert UnsupportedRoute();
    }

    function _sendCCTP(
        ChainConfig.ChainParams memory src, ChainConfig.ChainParams memory dst,
        uint256 usdcAmt, bool fast, uint256 cctpMaxFee, bytes memory payload, bool feeEligible
    ) internal returns (bytes32 transferId, bool sponsored) {
        // Real TokenMessengerV2 enforces `maxFee >= amount * minFee / 1e7` for EVERY burn (Fast and
        // Standard) whenever Circle's on-chain minFee > 0, so the caller's cap is always forwarded.
        // Only `feeExecuted` (set by Circle's attestation, <= maxFee) is actually deducted.
        uint256 maxFee = cctpMaxFee;
        if (maxFee >= usdcAmt) revert FeeTooHigh();

        // eligible: the vault adds the fee so the user receives the full amount.
        // The vault pays at most Circle's on-chain minFee + the owner-set Fast fee cap: `cctpMaxFee` is user
        // supplied and the unused part (maxFee - feeExecuted) reaches the recipient, so an uncapped
        // sponsorship would let anyone withdraw vault USDC through inflated fees.
        uint256 burnAmount = usdcAmt;
        if (maxFee > 0 && feeEligible) {
            uint256 cap = policy.cctpSponsorCap(usdcAmt, _cctpMinFee(usdcAmt), fast);
            uint256 sponsorAmt = maxFee < cap ? maxFee : cap;
            if (sponsorAmt > 0) {
                try vault.payUsdc(sponsorAmt) { burnAmount += sponsorAmt; sponsored = true; }
                catch { emit SponsorshipUnavailable(msg.sender, 2, sponsorAmt); } // vault empty: user's USDC pays
            }
        }

        IERC20(src.usdc).forceApprove(address(tokenMessenger), burnAmount);
        tokenMessenger.depositForBurnWithHook(
            burnAmount,
            dst.cctpDomain,
            _b32(dst.hub),          // mintRecipient = destination hub
            src.usdc,
            _b32(dst.hub),          // destinationCaller = destination hub (no front-running)
            maxFee,
            fast ? 1000 : 2000,     // 1000 = Fast, 2000 = Standard (finalized)
            payload
        );
        transferId = keccak256(abi.encode(localChainId, address(this), ++swapNonce));
    }

    function _sendStargate(
        ChainConfig.ChainParams memory src, ChainConfig.ChainParams memory dst,
        uint256 usdcAmt, uint256 maxNativeFee, uint256 nativeBudget, bytes memory payload, bool feeEligible
    ) internal returns (bytes32 transferId, bool sponsored, uint256 userNativeSpent) {
        IStargate sg = IStargate(src.stargatePool);
        SendParam memory sp = _sendParam(dst, usdcAmt, payload);

        // 1) Stargate token fee: eligible -> the vault adds it, so the destination receives usdcAmt in full.
        //    The fee comes from Stargate's own on-chain quote (not from user input).
        bool tokenFeeCovered = true;
        (uint256 tokenFee, uint256 rawFee) = _stargateTokenFee(sg, sp, usdcAmt);
        if (rawFee > 0) {
            tokenFeeCovered = false;
            if (feeEligible && tokenFee > 0) {
                try vault.payUsdc(tokenFee) { sp.amountLD = usdcAmt + tokenFee; tokenFeeCovered = true; } catch {}
            }
            if (!tokenFeeCovered) emit SponsorshipUnavailable(msg.sender, 4, rawFee);
        }
        (, , OFTReceipt memory r) = sg.quoteOFT(sp);
        sp.minAmountLD = r.amountReceivedLD;
        MessagingFee memory fee = sg.quoteSend(sp, false);   // live LayerZero fee (for the final amount)

        // 2) LayerZero native fee
        bool nativeCovered;
        if (feeEligible && fee.nativeFee > 0) {
            try vault.payNativeFee(fee.nativeFee) { nativeCovered = true; }
            catch { emit SponsorshipUnavailable(msg.sender, 1, fee.nativeFee); }
        }
        sponsored = feeEligible && tokenFeeCovered && (nativeCovered || fee.nativeFee == 0);
        if (!nativeCovered) {
            // Not sponsored: the user pays. If the user cannot (budget or consent too low) revert everything;
            // the Permit2 pull / WETH wrap are rolled back, so the tokens stay in the user's wallet.
            if (fee.nativeFee > maxNativeFee || nativeBudget < fee.nativeFee)
                revert FeeNotCovered(fee.nativeFee, nativeBudget, maxNativeFee);
            userNativeSpent = fee.nativeFee;
        }

        IERC20(src.usdc).forceApprove(address(sg), sp.amountLD);
        (MessagingReceipt memory mr, , ) = sg.sendToken{value: fee.nativeFee}(sp, fee, msg.sender);
        transferId = mr.guid;
    }

    /// @dev `extra` = USDC to add so that `target` arrives in full (Stargate's fee is proportional, so the
    ///      gross-up is refined twice); 0 when the grossed-up amount is outside Stargate's limits.
    ///      `rawFee` = the fee Stargate would deduct from `target` (0 = no fee or a reward).
    function _stargateTokenFee(IStargate sg, SendParam memory sp, uint256 target)
        internal view returns (uint256 extra, uint256 rawFee)
    {
        uint256 keep = sp.amountLD;
        sp.amountLD = target;
        (, , OFTReceipt memory r) = sg.quoteOFT(sp);
        if (r.amountReceivedLD < target) {
            rawFee = target - r.amountReceivedLD;
            extra = rawFee;
            for (uint256 i = 0; i < 2; i++) {
                sp.amountLD = target + extra;
                (OFTLimit memory lim, , OFTReceipt memory r2) = sg.quoteOFT(sp);
                if (sp.amountLD > lim.maxAmountLD) { extra = 0; break; }
                if (r2.amountReceivedLD >= target) break;
                extra += target - r2.amountReceivedLD;
            }
        }
        sp.amountLD = keep;
    }

    /// @dev Circle's on-chain minimum fee for a burn (0 when the messenger has no minFee function).
    function _cctpMinFee(uint256 amount) internal view returns (uint256 fee) {
        try ITokenMessengerV2(address(tokenMessenger)).getMinFeeAmount(amount) returns (uint256 f) { fee = f; } catch {}
    }

    /// @dev Bridge payload: the user's Delivery plus the hub-set expected amount (destination decimals).
    function _payload(Delivery calldata d, uint256 usdcAmt, ChainConfig.ChainParams memory src, ChainConfig.ChainParams memory dst)
        internal pure returns (bytes memory)
    {
        uint256 expected = dst.usdcDecimals >= src.usdcDecimals
            ? usdcAmt * 10 ** (dst.usdcDecimals - src.usdcDecimals)
            : usdcAmt / 10 ** (src.usdcDecimals - dst.usdcDecimals);
        return abi.encode(Envelope(d, expected));
    }

    function _sendParam(ChainConfig.ChainParams memory dst, uint256 amount, bytes memory payload)
        internal pure returns (SendParam memory)
    {
        return SendParam({
            dstEid: dst.lzEid,
            to: _b32(dst.hub),
            amountLD: amount,
            minAmountLD: 0,
            extraOptions: LzOptions.compose(dst.lzComposeGas), // gas for lzCompose on the destination
            composeMsg: payload,
            oftCmd: ""                                        // taxi mode (immediate, supports compose)
        });
    }

    // =====================================================================
    // Internal: destination
    // =====================================================================
    function _checkRemoteHub(uint256 srcChainId, address sender) internal view {
        if (srcChainId == 0) revert UntrustedSender();
        address trusted = config.getChain(srcChainId).hub;
        if (trusted == address(0) || trusted != sender) revert UntrustedSender();
    }

    function _deliver(bytes32 id, uint256 srcChainId, Envelope memory e, uint256 bridged) internal {
        if (processed[id]) revert AlreadyProcessed();
        processed[id] = true;

        ChainConfig.ChainParams memory local = config.getChain(localChainId);
        address usdc = local.usdc;
        Delivery memory d = e.d;

        // The recipient gets at most what the user swapped; unused sponsorship goes back to the vault.
        if (bridged > e.expectedUsdc) {
            uint256 surplus = bridged - e.expectedUsdc;
            bridged = e.expectedUsdc;
            IERC20(usdc).safeTransfer(address(vault), surplus);
            emit SurplusReturned(id, surplus);
        }

        address outToken = usdc;
        uint256 out = bridged;
        bool swapped;

        if (d.tokenOut != usdc) {
            if (block.timestamp <= d.deadline) {
                // Anti-griefing: the swap always gets exactly `swapGas`. If the caller supplied too
                // little gas the whole call reverts and the message stays executable.
                // (A plain 63/64 leftover check can be bypassed through nested calls.)
                uint256 g = swapGas;
                if (gasleft() < g + g / 63 + POST_SWAP_GAS) revert InsufficientGas();
                try this.executeSwap{gas: g}(local.uniswapRouter, usdc, d.tokenOut, d.dstPath, bridged, d.minAmountOut)
                    returns (uint256 o)
                { swapped = true; outToken = d.tokenOut; out = o; }
                catch {}
            }
        }

        _payout(local.wrappedNative, outToken, d.recipient, out, swapped && d.unwrapToNative);
        emit Delivered(id, srcChainId, d.recipient, outToken, bridged, out, swapped);
    }

    function _payout(address wrapped, address token, address to, uint256 amount, bool unwrap) internal {
        if (amount == 0) return;
        if (unwrap && token == wrapped) {
            IWETH(wrapped).withdraw(amount);
            // assembly call: return data is never copied, so a recipient cannot "return-bomb" the hub
            bool ok;
            uint256 g = NATIVE_PAYOUT_GAS;
            assembly { ok := call(g, to, amount, 0, 0, 0, 0) }
            if (ok) return;
            IWETH(wrapped).deposit{value: amount}(); // recipient rejected native: deliver wrapped token
        }
        if (!_tryTransfer(token, to, amount)) {
            unclaimed[to][token] += amount;
            unclaimedTotal[token] += amount;
            emit PayoutDeferred(to, token, amount);
        }
    }

    // =====================================================================
    // Internal: common
    // =====================================================================
    /// @dev UniversalRouter V3_SWAP_EXACT_IN (0x00): push tokens to the router, payerIsUser = false.
    ///      Returns the balance delta, never the full balance.
    function _swapExactIn(address router, address tIn, address tOut, bytes memory path, uint256 amountIn, uint256 minOut)
        internal returns (uint256 out)
    {
        V3Path.check(path, tIn, tOut);
        uint256 before = IERC20(tOut).balanceOf(address(this));
        IERC20(tIn).safeTransfer(router, amountIn);

        bytes[] memory inputs = new bytes[](1);
        inputs[0] = abi.encode(address(this), amountIn, minOut, path, false);
        IUniversalRouter(router).execute(hex"00", inputs, block.timestamp);

        out = IERC20(tOut).balanceOf(address(this)) - before;
        if (out < minOut) revert Slippage();
    }

    function _tryTransfer(address token, address to, uint256 amount) internal returns (bool) {
        (bool ok, bytes memory ret) = token.call(abi.encodeCall(IERC20.transfer, (to, amount)));
        if (!ok) return false;
        if (ret.length == 0) return token.code.length > 0;
        return ret.length >= 32 && abi.decode(ret, (uint256)) == 1; // malformed return data never reverts
    }

    function _setComponents(address c, address v, address o, address pol) internal {
        if (c == address(0) || v == address(0) || o == address(0) || pol == address(0)) revert ZeroAddress();
        config = ChainConfig(c);
        vault = ASwapVault(payable(v));
        oracle = PriceOracle(o);
        policy = SponsorshipPolicy(pol);
        emit ComponentsSet(c, v, o, pol);
    }

    function _setBridges(address p2, address tm, address mt, address ep) internal {
        permit2 = ISignatureTransfer(p2);
        tokenMessenger = ITokenMessengerV2(tm);
        messageTransmitter = IMessageTransmitterV2(mt);
        lzEndpoint = ep;
        emit BridgesSet(p2, tm, mt, ep);
    }

    function _b32(address a) internal pure returns (bytes32) { return bytes32(uint256(uint160(a))); }
}
