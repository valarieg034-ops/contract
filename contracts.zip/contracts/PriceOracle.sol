// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "@openzeppelin/contracts/utils/math/Math.sol";
import "./access/RegistryOwned.sol";
import "./interfaces/IExternal.sol";

/**
 * @title PriceOracle
 * @notice Chainlink-based USD valuation. Results use 8 decimals (usd8, $1 = 1e8).
 *
 *  - Token decimals are read from the token itself (never user supplied).
 *  - Feed decimals are honoured.
 *  - L2 sequencer uptime check (Arbitrum / Base / OP) with a grace period after restart.
 *  - `tryUsdValue` never reverts: (false, 0) on any failure, so an oracle outage cannot block swaps.
 */
contract PriceOracle is RegistryOwned {
    struct Feed { address aggregator; uint32 maxStaleness; }

    mapping(address => Feed) public feeds;
    address public sequencerUptimeFeed;   // set on L2s only (zero on L1)
    uint32  public sequencerGracePeriod = 3600;

    event FeedSet(address indexed token, address aggregator, uint32 maxStaleness);
    event SequencerFeedSet(address feed, uint32 gracePeriod);

    error FeedNotSet(address token);
    error BadPrice();
    error StalePrice();
    error SequencerDown();

    constructor(address registry) RegistryOwned(registry) {}

    function setFeed(address token, address aggregator, uint32 maxStaleness) external onlyOwner {
        if (token == address(0) || aggregator == address(0) || maxStaleness == 0) revert ZeroAddress();
        feeds[token] = Feed(aggregator, maxStaleness);
        emit FeedSet(token, aggregator, maxStaleness);
    }

    function setSequencerFeed(address feed, uint32 gracePeriod) external onlyOwner {
        sequencerUptimeFeed = feed;
        sequencerGracePeriod = gracePeriod;
        emit SequencerFeedSet(feed, gracePeriod);
    }

    /// @notice Reverts on any failure.
    function usdValue(address token, uint256 amount) public view returns (uint256 usd8) {
        Feed memory f = feeds[token];
        if (f.aggregator == address(0)) revert FeedNotSet(token);
        _checkSequencer();

        (, int256 answer, , uint256 updatedAt, ) = IAggregatorV3(f.aggregator).latestRoundData();
        if (answer <= 0) revert BadPrice();
        if (updatedAt > block.timestamp || block.timestamp - updatedAt > f.maxStaleness) revert StalePrice();

        uint8 feedDec = IAggregatorV3(f.aggregator).decimals();
        uint8 tokenDec = IERC20Metadata(token).decimals();
        // usd8 = amount * price * 1e8 / (10^tokenDec * 10^feedDec)
        usd8 = Math.mulDiv(amount, uint256(answer) * 1e8, 10 ** (uint256(tokenDec) + uint256(feedDec)));
    }

    /// @notice Non-reverting variant used by the Hub.
    function tryUsdValue(address token, uint256 amount) external view returns (bool ok, uint256 usd8) {
        try this.usdValue(token, amount) returns (uint256 v) { return (true, v); }
        catch { return (false, 0); }
    }

    function _checkSequencer() internal view {
        address feed = sequencerUptimeFeed;
        if (feed == address(0)) return;
        (, int256 answer, uint256 startedAt, , ) = IAggregatorV3(feed).latestRoundData();
        // answer 0 = up, 1 = down
        if (answer != 0 || startedAt == 0) revert SequencerDown(); // startedAt 0 = invalid round (Chainlink docs)
        if (block.timestamp - startedAt <= sequencerGracePeriod) revert SequencerDown();
    }
}
