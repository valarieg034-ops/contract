// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/*
 * External protocol interfaces, matching the real mainnet contract signatures.
 *  - Permit2 SignatureTransfer : permitTransferFrom selector 0x30f28b7a
 *  - Uniswap UniversalRouter   : execute(bytes,bytes[],uint256)
 *  - Circle CCTP V2            : TokenMessengerV2.depositForBurnWithHook / MessageTransmitterV2.receiveMessage
 *  - Stargate V2 (IOFT)        : quoteOFT / quoteSend / sendToken
 *  - LayerZero V2              : ILayerZeroComposer.lzCompose
 */

// ---------------- Permit2 (SignatureTransfer) ----------------
interface ISignatureTransfer {
    struct TokenPermissions { address token; uint256 amount; }
    struct PermitTransferFrom { TokenPermissions permitted; uint256 nonce; uint256 deadline; }
    struct SignatureTransferDetails { address to; uint256 requestedAmount; }

    function permitTransferFrom(
        PermitTransferFrom memory permit,
        SignatureTransferDetails calldata transferDetails,
        address owner,
        bytes calldata signature
    ) external;
}

// ---------------- Uniswap UniversalRouter ----------------
interface IUniversalRouter {
    function execute(bytes calldata commands, bytes[] calldata inputs, uint256 deadline) external payable;
}

// ---------------- Circle CCTP V2 ----------------
interface ITokenMessengerV2 {
    function depositForBurnWithHook(
        uint256 amount,
        uint32 destinationDomain,
        bytes32 mintRecipient,
        address burnToken,
        bytes32 destinationCaller,
        uint256 maxFee,
        uint32 minFinalityThreshold,
        bytes calldata hookData
    ) external;
    /// @notice Circle's on-chain minimum fee for `amount` (CCTP V2 with minFee).
    function getMinFeeAmount(uint256 amount) external view returns (uint256);
}

interface IMessageTransmitterV2 {
    function receiveMessage(bytes calldata message, bytes calldata attestation) external returns (bool);
}

// ---------------- Stargate V2 / LayerZero OFT ----------------
struct SendParam {
    uint32 dstEid;
    bytes32 to;
    uint256 amountLD;
    uint256 minAmountLD;
    bytes extraOptions;
    bytes composeMsg;
    bytes oftCmd;
}
struct MessagingFee { uint256 nativeFee; uint256 lzTokenFee; }
struct MessagingReceipt { bytes32 guid; uint64 nonce; MessagingFee fee; }
struct OFTLimit { uint256 minAmountLD; uint256 maxAmountLD; }
struct OFTFeeDetail { int256 feeAmountLD; string description; }
struct OFTReceipt { uint256 amountSentLD; uint256 amountReceivedLD; }
struct Ticket { uint72 ticketId; bytes passengerBytes; }

interface IStargate {
    function quoteOFT(SendParam calldata sendParam)
        external view returns (OFTLimit memory, OFTFeeDetail[] memory, OFTReceipt memory);
    function quoteSend(SendParam calldata sendParam, bool payInLzToken)
        external view returns (MessagingFee memory);
    function sendToken(SendParam calldata sendParam, MessagingFee calldata fee, address refundAddress)
        external payable returns (MessagingReceipt memory, OFTReceipt memory, Ticket memory);
    function token() external view returns (address);
}

interface ILayerZeroComposer {
    function lzCompose(
        address from,
        bytes32 guid,
        bytes calldata message,
        address executor,
        bytes calldata extraData
    ) external payable;
}

// ---------------- Misc ----------------
interface IWETH {
    function deposit() external payable;
    function withdraw(uint256 amount) external;
}

interface IAggregatorV3 {
    function decimals() external view returns (uint8);
    function description() external view returns (string memory);
    function latestRoundData()
        external view returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound);
}
