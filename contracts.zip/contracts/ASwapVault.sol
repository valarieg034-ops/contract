// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/utils/Pausable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./access/RegistryOwned.sol";
import "./access/FactoryInitializable.sol";

/**
 * @title ASwapVault
 * @notice The single treasury of one chain. Owners fund ONE address with native coin and USDC;
 *         the Hub draws every incentive from it:
 *
 *   native coin  -> LayerZero / Stargate bridge fee        (payNativeFee)
 *   USDC         -> CCTP fee and Stargate token fee        (payUsdc)
 *   USDC         -> bonus to the sender                    (payBonus)
 *
 *  Budgets (all owner-configurable):
 *   - nativeLimits : maxPerTx / dailyCap / minReserve for bridge fees
 *   - usdcLimits   : maxPerTx / dailyCap / minReserve for USDC fees
 *   - bonusDailyCap: daily cap for bonus payouts
 *   The USDC minReserve protects the whole USDC balance (fees and bonus alike).
 *
 *  Bonus delay (anti-Sybil): with `bonusDelay > 0` the bonus is granted as a pending claim that
 *  the user collects with `claimBonus()` after the delay. During the delay owners can cancel it
 *  (`cancelBonus`) when a wallet looks like a farming bot. Pending bonuses are reserved: fees can
 *  never spend them. `bonusDelay = 0` pays instantly.
 *
 *  Funding: send native coin to this address, transfer USDC to this address. Nothing else.
 *  Deployed with CREATE2 at the same address on every chain; USDC and limits are set in `initialize`.
 *  Nothing here can block a user's swap: when a budget is exhausted the Hub falls back to the
 *  user paying the fee, and `payBonus` simply returns false.
 */
contract ASwapVault is RegistryOwned, FactoryInitializable, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    struct Limits { uint256 maxPerTx; uint256 dailyCap; uint256 minReserve; }

    struct PendingBonus { uint128 amount; uint64 unlockAt; }

    IERC20 public usdc;
    mapping(address => bool) public authorizedHubs;

    Limits public nativeLimits;
    Limits public usdcLimits;
    uint256 public bonusDailyCap;
    mapping(address => bool) public bonusClaimed;
    uint64 public bonusDelay;                      // seconds; 0 = instant bonus
    mapping(address => PendingBonus) public pendingBonus;
    uint256 public totalPendingBonus;              // reserved USDC for pending bonuses
    uint64 public constant MAX_BONUS_DELAY = 30 days;

    uint256 public nativeUsedToday; uint256 public nativeDay;
    uint256 public usdcUsedToday;   uint256 public usdcDay;
    uint256 public bonusPaidToday;  uint256 public bonusDay;

    event NativeDeposited(address indexed from, uint256 amount);
    event HubAuthorized(address indexed hub, bool ok);
    event LimitsSet(Limits nativeLimits, Limits usdcLimits);
    event BonusDailyCapSet(uint256 cap);
    event NativeFeePaid(address indexed hub, uint256 amount);
    event UsdcPaid(address indexed hub, uint256 amount);
    event BonusPaid(address indexed user, uint256 amount);
    /// @notice reason: 1 already claimed, 2 daily cap, 3 balance / reserve, 4 paused
    event BonusSkipped(address indexed user, uint256 amount, uint8 reason);
    event BonusClaimReset(address indexed user);
    event BonusGranted(address indexed user, uint256 amount, uint64 unlockAt);
    event BonusCancelled(address indexed user, uint256 amount, address indexed by);
    event BonusDelaySet(uint64 delay);
    event Withdrawn(address indexed token, address indexed to, uint256 amount);

    error NotHub();
    error OverLimit();
    error TransferFailed();
    error InvalidLimits();
    error NothingToClaim();
    error Locked(uint64 unlockAt);

    modifier onlyHub() { if (!authorizedHubs[msg.sender]) revert NotHub(); _; }

    constructor(address registry) RegistryOwned(registry) {}

    function initialize(
        address _usdc, Limits calldata _native, Limits calldata _usdc_, uint256 _bonusDailyCap, uint64 _bonusDelay
    ) external initializer {
        if (_usdc == address(0) || _usdc.code.length == 0) revert ZeroAddress();
        usdc = IERC20(_usdc);
        _setLimits(_native, _usdc_);
        bonusDailyCap = _bonusDailyCap;
        _setBonusDelay(_bonusDelay);
        nativeDay = usdcDay = bonusDay = block.timestamp / 1 days;
    }

    receive() external payable { emit NativeDeposited(msg.sender, msg.value); }

    // =====================================================================
    // Views
    // =====================================================================
    function balances() external view returns (uint256 native, uint256 usdcBalance) {
        return (address(this).balance, usdc.balanceOf(address(this)));
    }

    /// @notice native coin payable right now for one bridge fee
    function availableNative() public view returns (uint256) {
        if (paused()) return 0;
        return _available(address(this).balance, nativeLimits, _today(nativeDay, nativeUsedToday));
    }

    /// @notice USDC payable right now for one fee / policy top-up
    function availableUsdc() public view returns (uint256) {
        if (paused()) return 0;
        return _available(_freeUsdc(), usdcLimits, _today(usdcDay, usdcUsedToday));
    }

    /// @notice USDC payable right now as bonus (daily cap and USDC reserve)
    function availableBonus() public view returns (uint256) {
        if (paused()) return 0;
        uint256 bal = _freeUsdc();
        uint256 reserve = usdcLimits.minReserve;
        if (bal <= reserve) return 0;
        uint256 used = _today(bonusDay, bonusPaidToday);
        if (used >= bonusDailyCap) return 0;
        uint256 a = bal - reserve;
        uint256 rem = bonusDailyCap - used;
        return a < rem ? a : rem;
    }

    function isClaimed(address user) external view returns (bool) { return bonusClaimed[user]; }

    // =====================================================================
    // Hub only
    // =====================================================================
    function payNativeFee(uint256 amount) external onlyHub nonReentrant whenNotPaused {
        if (amount == 0 || amount > availableNative()) revert OverLimit();
        _roll();
        nativeUsedToday += amount;
        (bool ok, ) = payable(msg.sender).call{value: amount}("");
        if (!ok) revert TransferFailed();
        emit NativeFeePaid(msg.sender, amount);
    }

    function payUsdc(uint256 amount) external onlyHub nonReentrant whenNotPaused {
        if (amount == 0 || amount > availableUsdc()) revert OverLimit();
        _roll();
        usdcUsedToday += amount;
        usdc.safeTransfer(msg.sender, amount);
        emit UsdcPaid(msg.sender, amount);
    }

    /// @notice Never reverts for business reasons (only for an unauthorized caller).
    /// @param oncePerWallet skip wallets that already received a bonus (policy setting).
    function payBonus(address user, uint256 amount, bool oncePerWallet) external onlyHub nonReentrant returns (bool) {
        if (amount == 0 || amount > type(uint128).max) return false;
        if (paused()) { emit BonusSkipped(user, amount, 4); return false; }
        if (oncePerWallet && bonusClaimed[user]) { emit BonusSkipped(user, amount, 1); return false; }
        _roll();
        if (bonusPaidToday + amount > bonusDailyCap) { emit BonusSkipped(user, amount, 2); return false; }
        if (_freeUsdc() < amount + usdcLimits.minReserve) { emit BonusSkipped(user, amount, 3); return false; }
        uint64 delay = bonusDelay;
        if (delay > 0 && uint256(pendingBonus[user].amount) + amount > type(uint128).max) { emit BonusSkipped(user, amount, 3); return false; }
        bonusClaimed[user] = true;
        bonusPaidToday += amount;
        if (delay == 0) {
            usdc.safeTransfer(user, amount);
            emit BonusPaid(user, amount);
        } else {
            uint64 unlockAt = uint64(block.timestamp) + delay;
            // several bonuses (oncePerWallet = false) accumulate; the newest one sets the unlock time
            pendingBonus[user] = PendingBonus(uint128(uint256(pendingBonus[user].amount) + amount), unlockAt);
            totalPendingBonus += amount;
            emit BonusGranted(user, amount, unlockAt);
        }
        return true;
    }

    // =====================================================================
    // User: collect a delayed bonus
    // =====================================================================
    function claimBonus() external nonReentrant whenNotPaused {
        PendingBonus memory b = pendingBonus[msg.sender];
        if (b.amount == 0) revert NothingToClaim();
        if (block.timestamp < b.unlockAt) revert Locked(b.unlockAt);
        delete pendingBonus[msg.sender];
        totalPendingBonus -= b.amount;
        usdc.safeTransfer(msg.sender, b.amount);
        emit BonusPaid(msg.sender, b.amount);
    }

    // =====================================================================
    // Owner
    // =====================================================================
    function setHubAuthorized(address hub, bool ok) external onlyOwner { authorizedHubs[hub] = ok; emit HubAuthorized(hub, ok); }
    function setLimits(Limits calldata n, Limits calldata u) external onlyOwner { _setLimits(n, u); }
    function setBonusDailyCap(uint256 cap) external onlyOwner { bonusDailyCap = cap; emit BonusDailyCapSet(cap); }
    function resetBonusClaim(address user) external onlyOwner { bonusClaimed[user] = false; emit BonusClaimReset(user); }
    function setBonusDelay(uint64 delay) external onlyOwner { _setBonusDelay(delay); }

    /// @notice Cancel a pending (not yet collected) bonus. The wallet stays marked as claimed.
    function cancelBonus(address user) external onlyOwner {
        PendingBonus memory b = pendingBonus[user];
        if (b.amount == 0) revert NothingToClaim();
        delete pendingBonus[user];
        totalPendingBonus -= b.amount;
        emit BonusCancelled(user, b.amount, msg.sender);
    }

    function withdrawNative(address payable to, uint256 amount) external onlyOwner nonReentrant {
        (bool ok, ) = to.call{value: amount}("");
        if (!ok) revert TransferFailed();
        emit Withdrawn(address(0), to, amount);
    }

    /// @notice Withdraw USDC or any token sent here by mistake. Pending (granted, not yet collected)
    ///         bonuses belong to users: cancel them first (`cancelBonus`, visible on-chain) to free them.
    function withdrawToken(address token, address to, uint256 amount) external onlyOwner nonReentrant {
        if (token == address(usdc) && usdc.balanceOf(address(this)) < amount + totalPendingBonus) revert OverLimit();
        IERC20(token).safeTransfer(to, amount);
        emit Withdrawn(token, to, amount);
    }

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    // =====================================================================
    // Internal
    // =====================================================================
    function _available(uint256 bal, Limits memory l, uint256 used) private pure returns (uint256 a) {
        if (bal <= l.minReserve || used >= l.dailyCap) return 0;
        a = bal - l.minReserve;
        if (a > l.maxPerTx) a = l.maxPerTx;
        uint256 rem = l.dailyCap - used;
        if (a > rem) a = rem;
    }

    function _freeUsdc() private view returns (uint256) {
        uint256 bal = usdc.balanceOf(address(this));
        uint256 p = totalPendingBonus;
        return bal > p ? bal - p : 0;
    }

    function _setBonusDelay(uint64 delay) private {
        if (delay > MAX_BONUS_DELAY) revert InvalidLimits();
        bonusDelay = delay;
        emit BonusDelaySet(delay);
    }

    function _today(uint256 day, uint256 used) private view returns (uint256) {
        return (block.timestamp / 1 days == day) ? used : 0;
    }

    function _roll() private {
        uint256 d = block.timestamp / 1 days;
        if (d != nativeDay) { nativeDay = d; nativeUsedToday = 0; }
        if (d != usdcDay)   { usdcDay = d;   usdcUsedToday = 0; }
        if (d != bonusDay)  { bonusDay = d;  bonusPaidToday = 0; }
    }

    function _setLimits(Limits memory n, Limits memory u) private {
        if (n.maxPerTx > n.dailyCap || u.maxPerTx > u.dailyCap) revert InvalidLimits();
        nativeLimits = n; usdcLimits = u;
        emit LimitsSet(n, u);
    }
}
