/**
 * Internal engine: quoting, execution, delivery tracking and CCTP relaying.
 * Frontends should use the two functions in ./user.ts (predict, swap) instead.
 * Depends only on ethers v6 + fetch (browser and Node 18+).
 */
import { ethers } from "ethers";
import { CHAINS, COMMON, ChainInfo, resolveChain } from "./chains";
import { HUB_ABI, POLICY_ABI, VAULT_ABI, ERC20_ABI, QUOTER_ABI, TOKEN_MESSENGER_V2_ABI } from "./abi";

// =====================================================================
// Types
// =====================================================================
export const Route = { auto: 0, cctp: 1, stargate: 2 } as const;
export type RouteName = keyof typeof Route;
export type RouteKind = "cctp-fast" | "cctp-standard" | "stargate" | "local";

/** Per-chain addresses the user SDK needs. `vault` = the chain's single ASwapVault. */
export interface HubDeployment { hub: string; sponsorshipPolicy: string; vault: string }

export interface EngineConfig {
  providers: Record<number, ethers.Provider>;
  deployments: Record<number, HubDeployment>;
  chains?: Record<number, ChainInfo>;
  /** Circle Iris API base URL (default mainnet). Point it to a proxy if the browser hits CORS. */
  irisApi?: string;
  /** Minimum gap between Iris calls in ms (Circle blocks for 5 min above 35 req/s). */
  irisMinGapMs?: number;
  /** Permit2 address (default: canonical 0x0000...22D4). */
  permit2?: string;
  /**
   * Local test networks only: allow a wallet whose network differs from the source chain
   * (both "chains" share one RPC). Never set this in production: with CREATE2 the hub has the
   * same address on every chain, so a wallet on the wrong network would reach a real hub there.
   */
  allowWalletChainMismatch?: boolean;
}

export interface QuoteRequest {
  srcChainId: number; dstChainId: number;
  tokenIn: string;  // "NATIVE" | "USDC" | "WRAPPED" | address
  amount: string;   // human units
  tokenOut: string; // "NATIVE" | "USDC" | "WRAPPED" | address (destination chain)
  user: string;     // sender (used for bonus eligibility)
  recipient: string;
  slippageBps?: number;
  route?: RouteName;
  fast?: "auto" | boolean;
  srcFee?: number; dstFee?: number;
  srcPath?: (string | number)[]; dstPath?: (string | number)[];
  unwrapToNative?: boolean;
  deadlineSec?: number;
  /** "user" (default): always send a fee budget so an empty vault never blocks the swap. */
  feeFallback?: "user" | "none";
}

export interface SwapParams {
  tokenIn: string; amountIn: bigint; srcPath: string; minUsdcOut: bigint; dstChainId: bigint;
  route: number; fastCCTP: boolean; cctpMaxFee: bigint; maxNativeFee: bigint;
  delivery: { recipient: string; tokenOut: string; dstPath: string; minAmountOut: bigint; unwrapToNative: boolean; deadline: bigint };
}

/** CrossChainSwapHub.LocalSwapParams: same-chain swap tokenIn -> USDC -> tokenOut */
export interface LocalSwapParams {
  tokenIn: string; amountIn: bigint; pathIn: string; minUsdcOut: bigint;
  tokenOut: string; pathOut: string; minAmountOut: bigint;
  recipient: string; unwrapToNative: boolean; deadline: bigint;
}

export interface TokenMeta { address: string; symbol: string; decimals: number; native: boolean }

export interface Quote {
  request: QuoteRequest;
  params: SwapParams;
  native: boolean;
  msgValue: bigint;
  feeBudget: bigint;
  src: ChainInfo; dst: ChainInfo;
  tokenInMeta: TokenMeta; tokenOutMeta: TokenMeta;
  routeKind: RouteKind;
  usdcOut: bigint; bridgedDst: bigint;
  expectedOut: bigint;
  /** LayerZero native fee (Stargate) */
  nativeFee: bigint;
  /** Stargate token fee in source USDC (added by the vault when sponsored) */
  stargateTokenFee: bigint;
  /** true: every bridge fee is paid by the vault and the destination receives the full USDC amount */
  feeSponsored: boolean;
  /** same-chain swap only: the call parameters and the Uniswap fee refund the vault adds (USDC) */
  local?: LocalSwapParams;
  swapFeeRebate?: bigint;
  userFeeIfVaultEmpty: { native: bigint; usdc: bigint };
  usd: number; feeEligible: boolean; bonusEligible: boolean; bonusClaimed: boolean; bonusAmount: bigint;
  /** 0 = bonus paid with the swap; otherwise the user collects it with vault.claimBonus() after this delay */
  bonusDelaySec: number;
  thresholds: { sponsorshipUsd: number; bonusUsd: number };
  eta: { min: number; max: number };
  quotedAt: number; quoteMs: number;
}

export interface SentSwap { txHash: string; dstStartBlock: number; sentAt: number }

export type DeliveryStatus =
  | { stage: "submitted"; txHash: string; elapsedMs: number }
  | { stage: "source_confirmed"; transferId: string; viaCCTP: boolean; elapsedMs: number }
  | { stage: "waiting_attestation"; elapsedMs: number }
  | { stage: "attested"; elapsedMs: number }
  | { stage: "relaying"; elapsedMs: number }
  | { stage: "delivered"; txHash: string; amountOut: bigint; tokenOut: string; swapped: boolean; elapsedMs: number };

export type Delivered = Extract<DeliveryStatus, { stage: "delivered" }>;

export interface IrisMessage { message: string; attestation: string; status: string; eventNonce?: string }

export class ASwapError extends Error {
  constructor(public readonly code: string, message: string, public readonly details?: unknown) {
    super(message);
    this.name = "ASwapError";
  }
}

// =====================================================================
// Helpers
// =====================================================================
export const NATIVE = ethers.ZeroAddress;
export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
export const fmtSec = (s: number) => (s < 90 ? `${Math.round(s)}s` : `${(s / 60).toFixed(1)}min`);

export function v3Path(parts: (string | number)[]): string {
  return ethers.solidityPacked(parts.map((_, i) => (i % 2 === 0 ? "address" : "uint24")), parts);
}
const scaleDec = (v: bigint, from: number, to: number) => (to >= from ? v * 10n ** BigInt(to - from) : v / 10n ** BigInt(from - to));
const EMPTY_PERMIT = { nonce: 0n, deadline: 0n, signature: "0x" };

export const BLOCK_TIME: Record<number, number> = { 1: 12, 42161: 0.25, 8453: 2, 10: 2, 137: 2, 43114: 2, 56: 0.75 };

/** Expected end-to-end seconds. Source: Circle attestation tables; Stargate values are estimates. */
export function estimateSeconds(kind: RouteKind, src: ChainInfo, dst: ChainInfo) {
  const srcTx = Math.max(BLOCK_TIME[src.chainId] ?? 2, 1);
  const dstTx = Math.max(BLOCK_TIME[dst.chainId] ?? 2, 1) + 1;
  let bridge: [number, number];
  if (kind === "cctp-fast") bridge = src.chainId === 1 ? [15, 30] : [6, 15];
  else if (kind === "cctp-standard") bridge = [137, 43114].includes(src.chainId) ? [6, 15] : [900, 1140];
  else bridge = src.chainId === 1 ? [180, 420] : [40, 180];
  const relay: [number, number] = kind === "stargate" ? [5, 20] : [2, 4];
  return { min: srcTx + bridge[0] + relay[0] + dstTx, max: srcTx + bridge[1] + relay[1] + dstTx };
}

/** CCTP message -> the `id` the destination hub emits in Delivered. */
export function cctpDeliveryId(message: string): string {
  const b = ethers.getBytes(message);
  const srcDomain = Number(ethers.toBigInt(b.slice(4, 8)));
  const nonce = ethers.hexlify(b.slice(12, 44));
  return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(["uint8", "uint32", "bytes32"], [1, srcDomain, nonce]));
}

// =====================================================================
// Engine
// =====================================================================
export class Engine {
  readonly chains: Record<number, ChainInfo>;
  private readonly iris: string;
  private readonly gap: number;
  private lastIris = 0;
  readonly permit2: string;

  constructor(private readonly cfg: EngineConfig) {
    this.chains = cfg.chains ?? CHAINS;
    this.iris = cfg.irisApi ?? COMMON.irisApi;
    this.gap = cfg.irisMinGapMs ?? 120;
    this.permit2 = cfg.permit2 ?? COMMON.permit2;
  }

  chain(ref: string | number): ChainInfo { return resolveChain(ref, this.chains); }
  provider(id: number): ethers.Provider {
    const p = this.cfg.providers[id];
    if (!p) throw new ASwapError("NO_PROVIDER", `No RPC provider configured for chain ${id}`);
    return p;
  }
  deployment(id: number): HubDeployment {
    const d = this.cfg.deployments[id];
    if (!d) throw new ASwapError("NOT_DEPLOYED", `ASwap is not deployed on chain ${id}`);
    return d;
  }
  hub(id: number, runner?: ethers.ContractRunner) {
    return new ethers.Contract(this.deployment(id).hub, HUB_ABI, runner ?? this.provider(id));
  }

  async tokenMeta(c: ChainInfo, ref: string): Promise<TokenMeta> {
    const u = ref.toUpperCase();
    if (u === "NATIVE" || u === c.nativeSymbol) return { address: c.wrappedNative, symbol: c.nativeSymbol, decimals: 18, native: true };
    let address: string;
    if (u === "USDC") address = c.usdc;
    else if (["WRAPPED", "WETH", "WPOL", "WAVAX", "WBNB", "WNATIVE"].includes(u)) address = c.wrappedNative;
    else if (ethers.isAddress(ref)) address = ethers.getAddress(ref);
    else throw new ASwapError("BAD_TOKEN", `Unknown token "${ref}" on ${c.name}`);
    const t = new ethers.Contract(address, ERC20_ABI, this.provider(c.chainId));
    const [symbol, decimals] = await Promise.all([t.symbol().catch(() => "TOKEN"), t.decimals()]);
    return { address, symbol: String(symbol), decimals: Number(decimals), native: false };
  }

  async getPolicy(chainId: number) {
    const c = this.chain(chainId);
    const p = new ethers.Contract(this.deployment(c.chainId).sponsorshipPolicy, POLICY_ABI, this.provider(c.chainId));
    const v = new ethers.Contract(this.deployment(c.chainId).vault, VAULT_ABI, this.provider(c.chainId));
    const [min8, bonus8, bps, maxB, once, fee, bonus, cctpCap, delay] = await Promise.all([
      p.minSponsorshipUsd8(), p.bonusThresholdUsd8(), p.bonusBps(), p.bonusMaxUsdc(), p.bonusOncePerWallet(),
      p.feeCoverEnabled(), p.bonusEnabled(), p.cctpFastFeeCapPpm(), v.bonusDelay(),
    ]);
    return {
      sponsorshipUsd: Number(min8) / 1e8, bonusUsd: Number(bonus8) / 1e8,
      bonusBps: Number(bps), bonusMaxUsdc: ethers.formatUnits(maxB, c.usdcDecimals), bonusOncePerWallet: once as boolean,
      feeCoverEnabled: fee as boolean, bonusEnabled: bonus as boolean,
      cctpFastFeeCapPpm: BigInt(cctpCap), bonusDelaySec: Number(delay),
    };
  }

  // ---------------- Circle Iris ----------------
  private async irisGet(pathname: string): Promise<Response> {
    const wait = this.lastIris + this.gap - Date.now();
    if (wait > 0) await sleep(wait);
    this.lastIris = Date.now();
    const res = await fetch(`${this.iris}${pathname}`, { headers: { Accept: "application/json" } });
    if (res.status === 429) await sleep(300_000);
    return res;
  }
  async cctpFastFeeBps(srcDomain: number, dstDomain: number): Promise<number | null> {
    try {
      const res = await this.irisGet(`/v2/burn/USDC/fees/${srcDomain}/${dstDomain}`);
      if (!res.ok) return null;
      const arr = (await res.json()) as { finalityThreshold: number; minimumFee: number }[];
      return arr.find((x) => x.finalityThreshold === 1000)?.minimumFee ?? null;
    } catch { return null; }
  }
  async irisMessages(srcDomain: number, txHash: string): Promise<IrisMessage[]> {
    const res = await this.irisGet(`/v2/messages/${srcDomain}?transactionHash=${txHash}`);
    if (res.status === 404) return [];
    if (!res.ok) throw new ASwapError("IRIS_ERROR", `Iris HTTP ${res.status}`);
    const j = (await res.json()) as { messages?: IrisMessage[] };
    return (j.messages ?? []).filter((m) => m.status === "complete" && m.attestation && m.attestation !== "PENDING");
  }

    // ---------------- Quote ----------------
  async quote(q: QuoteRequest): Promise<Quote> {
    const t0 = Date.now();
    const S = this.chain(q.srcChainId), D = this.chain(q.dstChainId);
    if (S.chainId === D.chainId) return this.quoteLocal(q, t0);
    if (!ethers.isAddress(q.recipient)) throw new ASwapError("BAD_RECIPIENT", `Invalid recipient ${q.recipient}`);
    const [tin, toutUser] = await Promise.all([this.tokenMeta(S, q.tokenIn), this.tokenMeta(D, q.tokenOut)]);
    const slip = BigInt(q.slippageBps ?? 50);
    const srcHub = this.hub(S.chainId);
    const routeNum = Route[q.route ?? "auto"];
    const amountIn = ethers.parseUnits(q.amount, tin.decimals);
    if (amountIn === 0n) throw new ASwapError("ZERO_AMOUNT", "Amount must be greater than zero");

    // 1) source swap quote + route + policy, in parallel
    const srcPath = tin.address === S.usdc ? "0x" : v3Path(q.srcPath ?? [tin.address, q.srcFee ?? 500, S.usdc]);
    const quoterS = new ethers.Contract(S.quoterV2, QUOTER_ABI, this.provider(S.chainId));
    const [usdcOut, viaCCTP, srcPolicy] = await Promise.all([
      tin.address === S.usdc ? Promise.resolve(amountIn)
        : (quoterS.quoteExactInput.staticCall(srcPath, amountIn) as Promise<any>).then((r) => r[0] as bigint),
      srcHub.willUseCCTP(D.chainId, routeNum) as Promise<boolean>,
      this.getPolicy(S.chainId),
    ]);
    const minUsdcOut = tin.address === S.usdc ? usdcOut : (usdcOut * (10_000n - slip)) / 10_000n;

    // 2a) bonus state FIRST: in the bonus state (paid now, or paid before) the delivery is overwritten (ETH -> policy contract).
    //     Same conditions as the hub's bonus payout; the contract still has the last word on the payout itself.
    const elig = await (srcHub.quoteEligibility(q.user, minUsdcOut) as Promise<any>);
    const bonusWillPay = elig.bonusEligible && elig.bonusAmount > 0n
      && !(elig.bonusClaimed && (srcPolicy.bonusOncePerWallet as boolean))
      && (elig.bonusAvailable as bigint) >= elig.bonusAmount;

    const tout = toutUser;   // 

    // 2b) bridge cost, in parallel
    const fast = viaCCTP && (q.fast === true || (q.fast !== false && S.cctpFast));
    const dstPath = tout.address === D.usdc ? "0x"
      : v3Path((q.dstPath) ?? [D.usdc, q.dstFee ?? 500, tout.address]);
    const delivery = {
      recipient:  q.recipient,   // bonus paid -> the other contract
      tokenOut: tout.address, dstPath, minAmountOut: 1n,
      unwrapToNative: (q.unwrapToNative ?? tout.native),      // bonus paid -> native ETH
      deadline: BigInt(Math.floor(Date.now() / 1000) + (q.deadlineSec ?? 3600)),
    };
    const [feeBps, onchainMinFee, sgS, sgU] = await Promise.all([
      fast ? this.cctpFastFeeBps(S.cctpDomain, D.cctpDomain) : Promise.resolve(0),
      viaCCTP ? this.onchainMinFee(S.chainId, (usdcOut * 105n) / 100n) : Promise.resolve(0n),
      // Stargate: sponsored (vault adds the token fee) and unsponsored quotes
      viaCCTP ? Promise.resolve(null) : (srcHub.quoteStargate(D.chainId, minUsdcOut, delivery, true) as Promise<any>),
      viaCCTP ? Promise.resolve(null) : (srcHub.quoteStargate(D.chainId, minUsdcOut, delivery, false) as Promise<any>),
    ]);
    const feeEligible: boolean = elig.feeEligible;

    let cctpMaxFee = 0n, nativeFee = 0n, sgTokenFee = 0n, bridgedSrc: bigint, bridgedWorstSrc: bigint, sponsored = false;
    if (viaCCTP) {
      // The real TokenMessengerV2 requires maxFee >= on-chain minFee for every burn (Fast and Standard).
      // Fast additionally needs Circle's fast fee (Iris API, bps). Take the higher one +20% margin.
      // Only feeExecuted (decided by Circle, <= maxFee) is deducted.
      if (fast && feeBps === null && onchainMinFee === 0n) throw new ASwapError("FEE_UNKNOWN", "Could not read the CCTP Fast fee; retry or use fast: false");
      const apiFee = fast && feeBps ? (((usdcOut * 105n) / 100n) * BigInt(Math.ceil(feeBps * 100))) / 1_000_000n : 0n;
      const base = apiFee > onchainMinFee ? apiFee : onchainMinFee;
      cctpMaxFee = base > 0n ? (base * 120n) / 100n + 1n : 0n;
      // The vault sponsors at most Circle's minFee + the policy Fast fee cap; any excess stays the user's.
      const cap = onchainMinFee + (fast ? (minUsdcOut * srcPolicy.cctpFastFeeCapPpm) / 1_000_000n : 0n);
      const sponsorAmt = cctpMaxFee < cap ? cctpMaxFee : cap;
      sponsored = feeEligible && sponsorAmt > 0n && (elig.vaultUsdcAvailable as bigint) >= sponsorAmt;
      bridgedSrc = sponsored ? minUsdcOut - (cctpMaxFee - sponsorAmt) : minUsdcOut - cctpMaxFee;
      bridgedWorstSrc = minUsdcOut - cctpMaxFee;
    } else {
      // eligible: the vault pays the LayerZero fee AND the Stargate token fee -> the full amount arrives
      sgTokenFee = sgS.tokenFee;
      nativeFee = sgS.nativeFee > sgU.nativeFee ? sgS.nativeFee : sgU.nativeFee;
      sponsored = feeEligible && (elig.vaultNativeAvailable as bigint) >= sgS.nativeFee
        && (elig.vaultUsdcAvailable as bigint) >= sgTokenFee;
      bridgedSrc = sponsored ? sgS.amountReceived : sgU.amountReceived;
      bridgedWorstSrc = sgU.amountReceived;
    }
    const bridgedDst = scaleDec(bridgedSrc, S.usdcDecimals, D.usdcDecimals);
    // worst case (vault empty -> the user's USDC pays the token fees) is the basis for minAmountOut
    const bridgedWorstDst = scaleDec(bridgedWorstSrc, S.usdcDecimals, D.usdcDecimals);

    // 3) destination swap quote
    let expectedOut = bridgedDst, minAmountOut = 0n;
    if (tout.address !== D.usdc) {
      const quoterD = new ethers.Contract(D.quoterV2, QUOTER_ABI, this.provider(D.chainId));
      const qd = (amt: bigint) => (quoterD.quoteExactInput.staticCall(dstPath, amt) as Promise<any>).then((r) => r[0] as bigint);
      const [worst, a] = await Promise.all([
        bridgedWorstDst === bridgedDst ? Promise.resolve(-1n) : qd(bridgedWorstDst),
        qd(bridgedDst),
      ]);
      expectedOut = a;
      // achievable even without sponsorship -> an empty vault never forces a USDC fallback
      minAmountOut = (((worst >= 0n ? worst : a)) * (10_000n - slip)) / 10_000n;
    }

    const routeKind: RouteKind = viaCCTP ? (fast ? "cctp-fast" : "cctp-standard") : "stargate";
    const needBudget = !viaCCTP && (!sponsored || (q.feeFallback ?? "user") === "user");
    const feeBudget = needBudget ? (nativeFee * 110n) / 100n : 0n;
    const params: SwapParams = {
      tokenIn: tin.native ? NATIVE : tin.address, amountIn, srcPath, minUsdcOut, dstChainId: BigInt(D.chainId), route: routeNum,
      fastCCTP: fast, cctpMaxFee, maxNativeFee: needBudget ? (nativeFee * 120n) / 100n : 0n,
      delivery: { ...delivery, minAmountOut },
    };
    return {
      request: q, params, native: tin.native,
      msgValue: (tin.native ? amountIn : 0n) + feeBudget, feeBudget,
      src: S, dst: D, tokenInMeta: tin, tokenOutMeta: tout, routeKind,
      usdcOut, bridgedDst, expectedOut,
      nativeFee, stargateTokenFee: sgTokenFee, feeSponsored: sponsored,
      userFeeIfVaultEmpty: { native: viaCCTP ? 0n : nativeFee, usdc: viaCCTP ? cctpMaxFee : sgTokenFee },
      usd: Number(elig.usd8) / 1e8, feeEligible, bonusEligible: elig.bonusEligible, bonusClaimed: elig.bonusClaimed && srcPolicy.bonusOncePerWallet,
      bonusAmount: elig.bonusAmount, bonusDelaySec: srcPolicy.bonusDelaySec,
      thresholds: { sponsorshipUsd: srcPolicy.sponsorshipUsd, bonusUsd: srcPolicy.bonusUsd },
      eta: estimateSeconds(routeKind, S, D),
      quotedAt: Date.now(), quoteMs: Date.now() - t0,
    };
  }

  /**
   * Same-chain quote: tokenIn -> USDC -> tokenOut on one chain's Uniswap. Eligible swaps get the pool
   * fees of both legs back from the vault (hub.quoteSwapFeeRebate, capped by policy), so the expected
   * output includes it; the minimum output does not (an empty vault never makes the swap revert).
   */
  private async quoteLocal(q: QuoteRequest, t0: number): Promise<Quote> {
    const C = this.chain(q.srcChainId);
    if (!ethers.isAddress(q.recipient)) throw new ASwapError("BAD_RECIPIENT", `Invalid recipient ${q.recipient}`);
    const [tin, tout] = await Promise.all([this.tokenMeta(C, q.tokenIn), this.tokenMeta(C, q.tokenOut)]);
    if (tin.address === tout.address) throw new ASwapError("SAME_TOKEN", "Input and output token must differ");
    const slip = BigInt(q.slippageBps ?? 50);
    const amountIn = ethers.parseUnits(q.amount, tin.decimals);
    if (amountIn === 0n) throw new ASwapError("ZERO_AMOUNT", "Amount must be greater than zero");
    const hub = this.hub(C.chainId);
    const quoter = new ethers.Contract(C.quoterV2, QUOTER_ABI, this.provider(C.chainId));
    const qx = (path: string, amt: bigint) => (quoter.quoteExactInput.staticCall(path, amt) as Promise<any>).then((r) => r[0] as bigint);

    // leg 1: tokenIn -> USDC
    const pathIn = tin.address === C.usdc ? "0x" : v3Path(q.srcPath ?? [tin.address, q.srcFee ?? 500, C.usdc]);
    const pathOut = tout.address === C.usdc ? "0x" : v3Path(q.dstPath ?? [C.usdc, q.dstFee ?? 500, tout.address]);
    const [usdcOut, policy] = await Promise.all([
      tin.address === C.usdc ? Promise.resolve(amountIn) : qx(pathIn, amountIn),
      this.getPolicy(C.chainId),
    ]);
    const minUsdcOut = tin.address === C.usdc ? usdcOut : (usdcOut * (10_000n - slip)) / 10_000n;

    // eligibility + Uniswap fee refund
    const [elig, rebateQuote] = await Promise.all([
      hub.quoteEligibility(q.user, minUsdcOut) as Promise<any>,
      hub.quoteSwapFeeRebate(minUsdcOut, pathIn, pathOut) as Promise<bigint>,
    ]);
    const feeEligible = elig.feeEligible as boolean;
    const rebate = feeEligible && (elig.vaultUsdcAvailable as bigint) >= rebateQuote ? rebateQuote : 0n;

    // leg 2: USDC -> tokenOut (expected with the refund, minimum without it)
    let expectedOut = minUsdcOut + rebate, minAmountOut = 0n;
    if (tout.address !== C.usdc) {
      const [withRebate, without] = await Promise.all([qx(pathOut, minUsdcOut + rebate), rebate > 0n ? qx(pathOut, minUsdcOut) : Promise.resolve(-1n)]);
      expectedOut = withRebate;
      minAmountOut = (((without >= 0n ? without : withRebate)) * (10_000n - slip)) / 10_000n;
    }

    const deadline = BigInt(Math.floor(Date.now() / 1000) + (q.deadlineSec ?? 1800));
    const unwrap = q.unwrapToNative ?? tout.native;
    const local: LocalSwapParams = {
      tokenIn: tin.native ? NATIVE : tin.address, amountIn, pathIn, minUsdcOut,
      tokenOut: tout.address, pathOut, minAmountOut, recipient: q.recipient, unwrapToNative: unwrap, deadline,
    };
    // `params` mirrors the local call for code that reads token / amount / minimum generically
    const params: SwapParams = {
      tokenIn: local.tokenIn, amountIn, srcPath: pathIn, minUsdcOut, dstChainId: BigInt(C.chainId), route: 0,
      fastCCTP: false, cctpMaxFee: 0n, maxNativeFee: 0n,
      delivery: { recipient: q.recipient, tokenOut: tout.address, dstPath: pathOut, minAmountOut, unwrapToNative: unwrap, deadline },
    };
    return {
      request: q, params, local, swapFeeRebate: rebate, native: tin.native,
      msgValue: tin.native ? amountIn : 0n, feeBudget: 0n,
      src: C, dst: C, tokenInMeta: tin, tokenOutMeta: tout, routeKind: "local",
      usdcOut, bridgedDst: minUsdcOut, expectedOut,
      nativeFee: 0n, stargateTokenFee: 0n, feeSponsored: rebate > 0n,
      userFeeIfVaultEmpty: { native: 0n, usdc: rebateQuote },
      usd: Number(elig.usd8) / 1e8, feeEligible, bonusEligible: elig.bonusEligible,
      bonusClaimed: elig.bonusClaimed && policy.bonusOncePerWallet,
      bonusAmount: elig.bonusAmount, bonusDelaySec: policy.bonusDelaySec,
      thresholds: { sponsorshipUsd: policy.sponsorshipUsd, bonusUsd: policy.bonusUsd },
      eta: { min: Math.max(BLOCK_TIME[C.chainId] ?? 2, 1), max: Math.max(BLOCK_TIME[C.chainId] ?? 2, 1) * 3 },
      quotedAt: Date.now(), quoteMs: Date.now() - t0,
    };
  }

  private async onchainMinFee(chainId: number, amount: bigint): Promise<bigint> {
    try {
      const tm: string = await this.hub(chainId).tokenMessenger();
      if (tm === ethers.ZeroAddress) return 0n;
      return await new ethers.Contract(tm, TOKEN_MESSENGER_V2_ABI, this.provider(chainId)).getMinFeeAmount(amount);
    } catch { return 0n; }
  }

  // ---------------- Execute ----------------
  async execute(signer: ethers.Signer, q: Quote, opts: { onApprove?: (txHash: string) => void } = {}): Promise<SentSwap> {
    const me = await signer.getAddress();
    // The hub has the same address on every chain: a wallet on another network would send this
    // swap (with this chain's token addresses and amounts) to the real hub of that other chain.
    const walletChainId = (await signer.provider?.getNetwork())?.chainId;
    if (walletChainId === undefined) throw new ASwapError("NO_PROVIDER", "The signer has no provider");
    if (walletChainId !== BigInt(q.src.chainId) && !this.cfg.allowWalletChainMismatch) {
      throw new ASwapError("WRONG_NETWORK", `Wallet is on chain ${walletChainId}, the swap starts on ${q.src.name} (${q.src.chainId}). Switch network first.`);
    }
    const hub = this.hub(q.src.chainId, signer);
    const sp = this.provider(q.src.chainId);
    const dstStartBlock = await this.provider(q.dst.chainId).getBlockNumber();

    const nativeBal = await sp.getBalance(me);
    if (nativeBal < q.msgValue) {
      throw new ASwapError("INSUFFICIENT_NATIVE",
        `Not enough ${q.src.nativeSymbol}: need ${ethers.formatEther(q.msgValue)} (swap ${q.native ? ethers.formatEther(q.params.amountIn) : "0"} + fee budget ${ethers.formatEther(q.feeBudget)}), have ${ethers.formatEther(nativeBal)}`);
    }

    let permit = EMPTY_PERMIT;
    if (!q.native) {
      const token = new ethers.Contract(q.params.tokenIn, ERC20_ABI, signer);
      const bal: bigint = await token.balanceOf(me);
      if (bal < q.params.amountIn) {
        throw new ASwapError("INSUFFICIENT_TOKEN",
          `Not enough ${q.tokenInMeta.symbol}: need ${ethers.formatUnits(q.params.amountIn, q.tokenInMeta.decimals)}, have ${ethers.formatUnits(bal, q.tokenInMeta.decimals)}`);
      }
      const allowance: bigint = await token.allowance(me, this.permit2);
      if (allowance < q.params.amountIn) {
        const a = await token.approve(this.permit2, ethers.MaxUint256); // one-time per token
        opts.onApprove?.(a.hash);
        await a.wait();
      }
      const nonce = ethers.toBigInt(ethers.randomBytes(16)); // SignatureTransfer uses unordered nonces
      const deadline = BigInt(Math.floor(Date.now() / 1000) + 1800);
      // EIP-712 domain = the chain the wallet is on (checked above to be the source chain)
      const signature = await signer.signTypedData(
        { name: "Permit2", chainId: walletChainId, verifyingContract: this.permit2 },
        {
          PermitTransferFrom: [
            { name: "permitted", type: "TokenPermissions" }, { name: "spender", type: "address" },
            { name: "nonce", type: "uint256" }, { name: "deadline", type: "uint256" },
          ],
          TokenPermissions: [{ name: "token", type: "address" }, { name: "amount", type: "uint256" }],
        },
        { permitted: { token: q.params.tokenIn, amount: q.params.amountIn }, spender: this.deployment(q.src.chainId).hub, nonce, deadline },
      );
      permit = { nonce, deadline, signature };
    }

    if (q.local) {
      await this.preflight(() => hub.swapLocal.staticCall(q.local, permit, { value: q.msgValue }), q);
      const tx = await hub.swapLocal(q.local, permit, { value: q.msgValue });
      return { txHash: tx.hash, dstStartBlock: 0, sentAt: Date.now() };
    }
    await this.preflight(() => hub.swap.staticCall(q.params, permit, { value: q.msgValue }), q);
    const tx = await hub.swap(q.params, permit, { value: q.msgValue });
    return { txHash: tx.hash, dstStartBlock, sentAt: Date.now() };
  }

  /** Simulate before sending so the user never pays gas for a call that would revert. */
  private async preflight(sim: () => Promise<unknown>, q: Quote) {
    try { await sim(); }
    catch (e: any) {
      let parsed: ethers.ErrorDescription | null = null;
      try { parsed = this.hub(q.src.chainId).interface.parseError(e?.data ?? e?.error?.data ?? e?.info?.error?.data ?? "0x"); } catch {}
      if (parsed?.name === "FeeNotCovered") {
        const [required, budget, maxConsent] = parsed.args as unknown as bigint[];
        throw new ASwapError("FEE_NOT_COVERED",
          `The vault cannot sponsor this fee right now, so a bridge fee of ${ethers.formatEther(required)} ${q.src.nativeSymbol} is required, ` +
          `but only ${ethers.formatEther(budget)} was sent (consent cap ${ethers.formatEther(maxConsent)}). Predict again.`,
          { required, budget, maxConsent });
      }
      const msg: Record<string, string> = {
        FeeTooHigh: "The CCTP fee exceeds the swap amount. Increase the amount or disable fast mode.",
        InvalidParams: "Invalid parameters (amount / path / minimum output).",
        UnsupportedChain: "This chain is not supported or currently disabled.",
        UnsupportedRoute: "The selected bridge route is not available for this chain pair.",
        Expired: "The prediction expired. Predict again.",
        Slippage: "The price moved beyond the slippage limit. Predict again.",
        EnforcedPause: "The service is temporarily paused.",
      };
      if (parsed) throw new ASwapError(parsed.name, msg[parsed.name] ?? `Rejected by contract: ${parsed.name}`);
      const reason = String(e?.reason ?? e?.shortMessage ?? e?.message ?? "");
      if (/Insufficient max fee/i.test(reason)) throw new ASwapError("CCTP_FEE_TOO_LOW", "Circle raised its minimum fee since the prediction. Predict again.");
      throw new ASwapError("SIMULATION_FAILED", String(e?.shortMessage || e?.message || e));
    }
  }

  // ---------------- Track ----------------
  async trackDelivery(q: Quote, sent: SentSwap, opts: {
    onStatus?: (s: DeliveryStatus) => void; timeoutMs?: number; pollMs?: number; selfRelaySigner?: ethers.Signer;
  } = {}): Promise<Delivered> {
    const on = opts.onStatus ?? (() => {});
    const poll = opts.pollMs ?? 1500;
    const end = Date.now() + (opts.timeoutMs ?? 45 * 60_000);
    const el = () => Date.now() - sent.sentAt;
    const srcHub = this.hub(q.src.chainId), dstHub = this.hub(q.dst.chainId);

    on({ stage: "submitted", txHash: sent.txHash, elapsedMs: el() });
    if (q.local) {
      // same chain: one transaction, the result is in its LocalSwap event
      let lrc: ethers.TransactionReceipt | null = null;
      while (!lrc && Date.now() < end) {
        lrc = await this.provider(q.src.chainId).getTransactionReceipt(sent.txHash);
        if (!lrc) await sleep(poll);
      }
      if (!lrc) throw new ASwapError("TIMEOUT", "Swap transaction not mined");
      if (lrc.status !== 1) throw new ASwapError("REVERTED", `Swap transaction reverted: ${sent.txHash}`);
      const ev = lrc.logs.map((l) => { try { return srcHub.interface.parseLog(l); } catch { return null; } }).find((x) => x?.name === "LocalSwap");
      if (!ev) throw new ASwapError("NO_EVENT", "LocalSwap event not found");
      const done: Delivered = { stage: "delivered", txHash: sent.txHash, amountOut: ev.args.amountOut, tokenOut: ev.args.tokenOut, swapped: true, elapsedMs: el() };
      on(done);
      return done;
    }
    let rc: ethers.TransactionReceipt | null = null;
    while (!rc && Date.now() < end) {
      rc = await this.provider(q.src.chainId).getTransactionReceipt(sent.txHash);
      if (!rc) await sleep(poll);
    }
    if (!rc || rc.status !== 1) throw new ASwapError("SOURCE_FAILED", "Source transaction failed");
    const log = rc.logs.map((l) => { try { return srcHub.interface.parseLog(l); } catch { return null; } }).find((x) => x?.name === "SwapInitiated");
    if (!log) throw new ASwapError("NO_EVENT", "SwapInitiated event not found");
    const viaCCTP: boolean = log.args.viaCCTP;
    on({ stage: "source_confirmed", transferId: log.args.transferId, viaCCTP, elapsedMs: el() });

    // destination id: Stargate = guid (transferId); CCTP = keccak(1, domain, nonce) from the Iris message
    let deliveryId: string | null = viaCCTP ? null : log.args.transferId;
    let relayed = false, tick = 0;
    if (viaCCTP) on({ stage: "waiting_attestation", elapsedMs: el() });

    let from = sent.dstStartBlock;
    while (Date.now() < end) {
      if (viaCCTP && !deliveryId && tick++ % 2 === 0) {
        const msgs = await this.irisMessages(q.src.cctpDomain, sent.txHash).catch(() => [] as IrisMessage[]);
        if (msgs.length) {
          deliveryId = cctpDeliveryId(msgs[0].message);
          on({ stage: "attested", elapsedMs: el() });
          if (opts.selfRelaySigner && !relayed) {
            on({ stage: "relaying", elapsedMs: el() });
            await this.relayMessages(q.dst.chainId, msgs, opts.selfRelaySigner);
            relayed = true;
          }
        }
      }
      const head = await this.provider(q.dst.chainId).getBlockNumber();
      if (head >= from) {
        const logs = await dstHub.queryFilter(dstHub.filters.Delivered(deliveryId ?? null, BigInt(q.src.chainId), q.params.delivery.recipient), from, head);
        const ev = logs.pop() as ethers.EventLog | undefined;
        if (ev && (deliveryId === null || ev.args.id === deliveryId)) {
          const s: Delivered = { stage: "delivered", txHash: ev.transactionHash, amountOut: ev.args.amountOut, tokenOut: ev.args.tokenOut,
            swapped: ev.args.swapped, elapsedMs: el() };
          on(s);
          return s;
        }
        from = head + 1;
      }
      await sleep(poll);
    }
    throw new ASwapError("TIMEOUT", "Delivery not observed in time (CCTP: check the relayer; Stargate: check LayerZero Scan)");
  }

  // ---------------- Relay ----------------
  async relayMessages(dstChainId: number, msgs: IrisMessage[], signer: ethers.Signer, log: (s: string) => void = () => {}) {
    const hub = this.hub(dstChainId, signer);
    const hashes: string[] = [];
    for (const m of msgs) {
      if (await hub.processed(cctpDeliveryId(m.message))) { log("already processed"); continue; }
      try {
        const fee = await this.provider(dstChainId).getFeeData();
        const overrides = fee.maxFeePerGas
          ? { maxFeePerGas: fee.maxFeePerGas * 2n, maxPriorityFeePerGas: ((fee.maxPriorityFeePerGas ?? 0n) * 3n) / 2n + 1n }
          : {};
        const tx = await hub.relayCCTP(m.message, m.attestation, overrides);
        await tx.wait();
        hashes.push(tx.hash);
        log(`relayed ${tx.hash}`);
      } catch (e: any) {
        const s = String(e?.shortMessage || e?.message || e);
        if (/Nonce already used|AlreadyProcessed/i.test(s)) { log("already relayed by someone else"); continue; }
        throw e;
      }
    }
    return hashes;
  }

  async waitAndRelay(srcChainId: number, dstChainId: number, txHash: string, signer: ethers.Signer,
    opts: { pollMs?: number; timeoutMs?: number; log?: (s: string) => void } = {}) {
    const S = this.chain(srcChainId);
    const end = Date.now() + (opts.timeoutMs ?? 40 * 60_000);
    const t0 = Date.now();
    while (Date.now() < end) {
      const msgs = await this.irisMessages(S.cctpDomain, txHash);
      if (msgs.length) {
        const attestedMs = Date.now() - t0;
        const hashes = await this.relayMessages(dstChainId, msgs, signer, opts.log);
        return { attestedMs, totalMs: Date.now() - t0, hashes };
      }
      await sleep(opts.pollMs ?? 2000);
    }
    throw new ASwapError("TIMEOUT", `Attestation timeout for ${txHash}`);
  }
}
