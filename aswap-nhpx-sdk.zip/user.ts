/**
 * User API — exactly two functions:
 *
 *   const aswap = createASwap({ providers, deployments });
 *
 *   // 1) predict the destination amount (no wallet needed)
 *   const p = await aswap.predict({
 *     srcChain: "base", srcToken: "NATIVE", amount: "0.5",
 *     dstChain: "arbitrum", dstToken: "USDC", recipient: "0xReceiver",
 *   });
 *   p.amountOut      // "1234.56"  expected (with incentives)
 *   p.amountOutMin   // "1228.40"  guaranteed minimum
 *
 *   // 2) execute (one wallet confirmation; ERC20 also signs a gas-free Permit2 message)
 *   const r = await aswap.swap(signer, p, { onStatus: (s) => render(s) });
 *   r.amountOut, r.dstTxHash, r.elapsedMs
 */
import { ethers } from "ethers";
import {
  Engine, EngineConfig, Quote, QuoteRequest, DeliveryStatus, ASwapError, RouteKind, RouteName, fmtSec,
} from "./engine";

export interface SwapInput {
  srcChain: string | number;   // "base" | 8453
  srcToken: string;            // "NATIVE" | "USDC" | "WETH" | token address
  amount: string;              // human units, e.g. "0.5"
  dstChain: string | number;
  dstToken: string;            // "NATIVE" | "USDC" | "WETH" | token address on the destination chain
  recipient: string;           // destination address
}

export interface SwapOptions {
  /** Who sends the swap (bonus eligibility). Defaults to the recipient for predict, the signer for swap. */
  sender?: string;
  slippageBps?: number;        // default 50 (0.5%)
  route?: RouteName;           // "auto" (default) | "cctp" | "stargate"
  fast?: "auto" | boolean;     // CCTP Fast
  feeFallback?: "user" | "none";
  deadlineSec?: number;
  srcFee?: number; dstFee?: number;
  srcPath?: (string | number)[]; dstPath?: (string | number)[];
  unwrapToNative?: boolean;
}

export interface Prediction {
  input: SwapInput;
  options: SwapOptions;
  /** expected amount the recipient receives (human units) */
  amountOut: string;
  /** guaranteed minimum (human units). Below this the recipient gets USDC instead. */
  amountOutMin: string;
  tokenOut: { address: string; symbol: string; decimals: number; native: boolean };
  tokenIn: { address: string; symbol: string; decimals: number; native: boolean };
  usdValue: number;
  route: RouteKind;
  /** native coin the wallet must send (swap amount for NATIVE input + fee budget). Unused part is refunded. */
  payNative: string;
  fees: {
    sponsored: boolean;
    bridgeFeeNative: string;   // LayerZero fee (Stargate) in native units, "0" for CCTP
    bridgeFeeUsdc: string;     // CCTP max fee or Stargate token fee in source USDC
    /** sponsored = the vault pays all of these and the destination receives the full USDC amount */
    ifVaultEmpty: { native: string; usdc: string };
  };
  incentives: {
    sponsorshipThresholdUsd: number;
    bonusThresholdUsd: number;
    /** Paid in source-chain USDC to the sender. claimAfterSec = 0: with the swap; > 0: `claimBonus` after the delay. */
    bonus: { eligible: boolean; alreadyClaimed: boolean; amountUsdc: string; claimAfterSec: number };
  };
  eta: { minSec: number; maxSec: number; text: string };
  createdAt: number;
  /** internal, pass the whole object back to swap() */
  quote: Quote;
}

export interface SwapResult {
  srcTxHash: string;
  dstTxHash: string;
  amountOut: string;           // human units actually received
  tokenOut: string;            // token address actually delivered (USDC on fallback)
  swapped: boolean;            // a destination swap was executed (always false when the requested token is USDC)
  fallback: boolean;           // true = the requested token could not be bought, the recipient got USDC instead
  elapsedMs: number;
}

export interface SwapRunOptions {
  onStatus?: (s: DeliveryStatus) => void;
  onApprove?: (txHash: string) => void;
  /** re-predict when the prediction is older than this (default 30 s) */
  maxAgeMs?: number;
  /** fail with PRICE_CHANGED if the fresh minimum dropped more than this vs the prediction (default 50 bps) */
  maxPriceDropBps?: number;
  /** wait for delivery (default true). false returns right after the source transaction is sent. */
  wait?: boolean;
  /** relay the CCTP message yourself (needs gas on the destination chain) */
  selfRelaySigner?: ethers.Signer;
  timeoutMs?: number;
  pollMs?: number;
}

export function createASwap(config: EngineConfig) {
  const engine = new Engine(config);

  const toRequest = (input: SwapInput, opt: SwapOptions, sender: string): QuoteRequest => ({
    srcChainId: engine.chain(input.srcChain).chainId,
    dstChainId: engine.chain(input.dstChain).chainId,
    tokenIn: input.srcToken, amount: input.amount, tokenOut: input.dstToken,
    user: sender, recipient: input.recipient,
    slippageBps: opt.slippageBps, route: opt.route, fast: opt.fast, feeFallback: opt.feeFallback,
    deadlineSec: opt.deadlineSec, srcFee: opt.srcFee, dstFee: opt.dstFee,
    srcPath: opt.srcPath, dstPath: opt.dstPath, unwrapToNative: opt.unwrapToNative,
  });

  const toPrediction = (input: SwapInput, options: SwapOptions, q: Quote): Prediction => {
    const outDec = q.params.delivery.tokenOut === q.dst.usdc ? q.dst.usdcDecimals : q.tokenOutMeta.decimals;
    const minRaw = q.params.delivery.minAmountOut || q.bridgedDst;
    return {
      input, options,
      amountOut: ethers.formatUnits(q.expectedOut, outDec),
      amountOutMin: ethers.formatUnits(minRaw, outDec),
      tokenOut: q.tokenOutMeta, tokenIn: q.tokenInMeta,
      usdValue: q.usd, route: q.routeKind,
      payNative: ethers.formatEther(q.msgValue),
      fees: {
        sponsored: q.feeSponsored,
        bridgeFeeNative: ethers.formatEther(q.nativeFee),
        bridgeFeeUsdc: ethers.formatUnits(q.params.cctpMaxFee + q.stargateTokenFee + (q.swapFeeRebate ?? 0n), q.src.usdcDecimals),
        ifVaultEmpty: {
          native: ethers.formatEther(q.userFeeIfVaultEmpty.native),
          usdc: ethers.formatUnits(q.userFeeIfVaultEmpty.usdc, q.src.usdcDecimals),
        },
      },
      incentives: {
        sponsorshipThresholdUsd: q.thresholds.sponsorshipUsd,
        bonusThresholdUsd: q.thresholds.bonusUsd,
        bonus: { eligible: q.bonusEligible, alreadyClaimed: q.bonusClaimed, amountUsdc: ethers.formatUnits(q.bonusAmount, q.src.usdcDecimals), claimAfterSec: q.bonusDelaySec },
      },
      eta: { minSec: q.eta.min, maxSec: q.eta.max, text: `${fmtSec(q.eta.min)} - ${fmtSec(q.eta.max)}` },
      createdAt: q.quotedAt,
      quote: q,
    };
  };

  /** 1) Predict the destination amount. No wallet needed. */
  async function predict(input: SwapInput, options: SwapOptions = {}): Promise<Prediction> {
    const q = await engine.quote(toRequest(input, options, options.sender ?? input.recipient));
    return toPrediction(input, options, q);
  }

  /** 2) Execute the swap. Accepts a Prediction (recommended) or the raw input. */
  async function swap(signer: ethers.Signer, what: Prediction | SwapInput, run: SwapRunOptions = {}): Promise<SwapResult> {
    const me = await signer.getAddress();
    const given = "quote" in what ? what : null;
    const input = given ? given.input : (what as SwapInput);
    const options: SwapOptions = { ...(given?.options ?? {}), sender: me };

    // re-predict when stale or predicted for another sender
    let p = given;
    const stale = !p || Date.now() - p.createdAt > (run.maxAgeMs ?? 30_000) || p.quote.request.user.toLowerCase() !== me.toLowerCase();
    if (stale) {
      const fresh = await predict(input, options);
      if (p) {
        const oldMin = p.quote.params.delivery.minAmountOut || p.quote.bridgedDst;
        const newMin = fresh.quote.params.delivery.minAmountOut || fresh.quote.bridgedDst;
        const dropBps = oldMin > 0n ? Number(((oldMin - newMin) * 10_000n) / oldMin) : 0;
        if (dropBps > (run.maxPriceDropBps ?? 50)) {
          throw new ASwapError("PRICE_CHANGED",
            `Price moved: minimum output fell from ${p.amountOutMin} to ${fresh.amountOutMin} ${fresh.tokenOut.symbol}. Confirm the new prediction.`,
            { prediction: fresh });
        }
      }
      p = fresh;
    }

    const srcNet = await signer.provider?.getNetwork();
    // only enforced when the wallet is on another *known* chain (local test nodes are skipped)
    if (srcNet && engine.chains[Number(srcNet.chainId)] && Number(srcNet.chainId) !== p!.quote.src.chainId) {
      throw new ASwapError("WRONG_NETWORK", `Switch your wallet to ${p!.quote.src.name} (chainId ${p!.quote.src.chainId})`);
    }

    const sent = await engine.execute(signer, p!.quote, { onApprove: run.onApprove });
    if (run.wait === false) {
      return { srcTxHash: sent.txHash, dstTxHash: "", amountOut: "", tokenOut: "", swapped: false, fallback: false, elapsedMs: Date.now() - sent.sentAt };
    }
    const d = await engine.trackDelivery(p!.quote, sent, {
      onStatus: run.onStatus, selfRelaySigner: run.selfRelaySigner, timeoutMs: run.timeoutMs, pollMs: run.pollMs,
    });
    const q = p!.quote;
    const dec = d.tokenOut.toLowerCase() === q.dst.usdc.toLowerCase() ? q.dst.usdcDecimals : q.tokenOutMeta.decimals;
    return {
      srcTxHash: sent.txHash, dstTxHash: d.txHash, amountOut: ethers.formatUnits(d.amountOut, dec),
      tokenOut: d.tokenOut, swapped: d.swapped,
      fallback: !d.swapped && q.params.delivery.tokenOut.toLowerCase() !== q.dst.usdc.toLowerCase(),
      elapsedMs: d.elapsedMs,
    };
  }

  return { predict, swap, engine };
}

export type ASwapClient = ReturnType<typeof createASwap>;
