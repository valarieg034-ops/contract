/**
 * Chain addresses and parameters.
 *
 * Sources (verified 2026-11):
 *  - Stargate V2 USDC pools : @stargatefinance/stg-evm-sdk-v2 deployments/<chain>-mainnet/StargatePoolUSDC.json
 *  - Uniswap UniversalRouter: @uniswap/universal-router-sdk UNIVERSAL_ROUTER_ADDRESS(V2_0, chainId)
 *  - Uniswap QuoterV2       : Uniswap deployment docs / @uniswap/sdk-core
 *  - CCTP V2                : Circle (same address on every EVM chain)
 *  - LayerZero V2 endpoint  : LayerZero (same address on every EVM chain)
 *  - Chainlink USDC/USD     : data.chain.link (re-verified on-chain by the deploy step)
 *
 * The deploy step checks code existence, Stargate pool token == USDC, USDC decimals and the
 * Chainlink feed description/freshness, and aborts on any mismatch.
 */

export const COMMON = {
  permit2: "0x000000000022D473030F116dDEE9F6B43aC78BA3",
  tokenMessengerV2: "0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d",
  messageTransmitterV2: "0x81D40F21F12A8F0E3252Bccb954D722d4c464B64",
  lzEndpointV2: "0x1a44076050125825900e736c501f859c50fE728c",
  irisApi: "https://iris-api.circle.com",
};

export interface ChainInfo {
  name: string;
  chainId: number;
  rpcEnv: string;              // env var holding the RPC URL
  cctpEnabled: boolean;
  cctpDomain: number;
  lzEid: number;
  usdc: string;
  usdcDecimals: number;
  wrappedNative: string;
  nativeSymbol: string;
  uniswapRouter: string;       // UniversalRouter (V2_0)
  quoterV2: string;            // off-chain quotes
  stargatePool: string;        // Stargate V2 USDC pool
  usdcUsdFeed: string;         // Chainlink USDC/USD
  sequencerFeed?: string;      // L2 sequencer uptime feed
  lzComposeGas: number;        // gas for lzCompose on this chain (>= Hub.swapGas + ~400k)
  cctpFast: boolean;           // use CCTP Fast when sourcing from this chain (false where Standard is already ~8 s)
  // vault native limits for bridge fees (native coin units)
  native: { maxPerTx: string; dailyCap: string; minReserve: string };
}

export const CHAINS: Record<number, ChainInfo> = {
  1: {
    name: "ethereum", chainId: 1, rpcEnv: "ETHEREUM_RPC_URL",
    cctpEnabled: true, cctpDomain: 0, lzEid: 30101,
    usdc: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", usdcDecimals: 6,
    wrappedNative: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", nativeSymbol: "ETH",
    uniswapRouter: "0x66a9893cc07d91d95644aedd05d03f95e1dba8af",
    quoterV2: "0x61fFE014bA17989E743c5F6cB21bF9697530B21e",
    stargatePool: "0xc026395860Db2d07ee33e05fE50ed7bD583189C7",
    usdcUsdFeed: "0x8fFfFfd4AfB6115b954Bd326cbe7B4BA576818f6",
    lzComposeGas: 1_200_000, cctpFast: true,
    native: { maxPerTx: "0.005", dailyCap: "0.2", minReserve: "0.02" },
  },
  42161: {
    name: "arbitrum", chainId: 42161, rpcEnv: "ARBITRUM_RPC_URL",
    cctpEnabled: true, cctpDomain: 3, lzEid: 30110,
    usdc: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831", usdcDecimals: 6,
    wrappedNative: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1", nativeSymbol: "ETH",
    uniswapRouter: "0xa51afafe0263b40edaef0df8781ea9aa03e381a3",
    quoterV2: "0x61fFE014bA17989E743c5F6cB21bF9697530B21e",
    stargatePool: "0xe8CDF27AcD73a434D661C84887215F7598e7d0d3",
    usdcUsdFeed: "0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3",
    sequencerFeed: "0xFdB631F5EE196F0ed6FAa767959853A9F217697D",
    lzComposeGas: 2_000_000, cctpFast: true, // Arbitrum gas units are larger
    native: { maxPerTx: "0.002", dailyCap: "0.1", minReserve: "0.005" },
  },
  8453: {
    name: "base", chainId: 8453, rpcEnv: "BASE_RPC_URL",
    cctpEnabled: true, cctpDomain: 6, lzEid: 30184,
    usdc: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", usdcDecimals: 6,
    wrappedNative: "0x4200000000000000000000000000000000000006", nativeSymbol: "ETH",
    uniswapRouter: "0x6ff5693b99212da76ad316178a184ab56d299b43",
    quoterV2: "0x3d4e44Eb1374240CE5F1B871ab261CD16335B76a",
    stargatePool: "0x27a16dc786820B16E5c9028b75B99F6f604b5d26",
    usdcUsdFeed: "0x7e860098F58bBFC8648a4311b374B1D669a2bc6B",
    sequencerFeed: "0xBCF85224fc0756B9Fa45aA7892530B47e10b6433",
    lzComposeGas: 1_200_000, cctpFast: true,
    native: { maxPerTx: "0.002", dailyCap: "0.1", minReserve: "0.005" },
  },
  10: {
    name: "optimism", chainId: 10, rpcEnv: "OPTIMISM_RPC_URL",
    cctpEnabled: true, cctpDomain: 2, lzEid: 30111,
    usdc: "0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85", usdcDecimals: 6,
    wrappedNative: "0x4200000000000000000000000000000000000006", nativeSymbol: "ETH",
    uniswapRouter: "0x851116d9223fabed8e56c0e6b8ad0c31d98b3507",
    quoterV2: "0x61fFE014bA17989E743c5F6cB21bF9697530B21e",
    stargatePool: "0xcE8CcA271Ebc0533920C83d39F417ED6A0abB7D0",
    usdcUsdFeed: "0x16a9FA2FDa030272Ce99B29CF780dFA30361E0f3",
    sequencerFeed: "0x371EAD81c9102C9BF4874A9075FFFf170F2Ee389",
    lzComposeGas: 1_200_000, cctpFast: true,
    native: { maxPerTx: "0.002", dailyCap: "0.1", minReserve: "0.005" },
  },
  137: {
    name: "polygon", chainId: 137, rpcEnv: "POLYGON_RPC_URL",
    cctpEnabled: true, cctpDomain: 7, lzEid: 30109,
    usdc: "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359", usdcDecimals: 6,
    wrappedNative: "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270", nativeSymbol: "POL",
    uniswapRouter: "0x1095692a6237d83c6a72f3f5efedb9a670c49223",
    quoterV2: "0x61fFE014bA17989E743c5F6cB21bF9697530B21e",
    stargatePool: "0x9Aa02D4Fae7F58b8E8f34c66E756cC734DAc7fe4",
    usdcUsdFeed: "0xfE4A8cc5b5B2366C1B58Bea3858e81843581b2F7",
    lzComposeGas: 1_200_000, cctpFast: false, // Standard is already ~8 s
    native: { maxPerTx: "5", dailyCap: "200", minReserve: "10" },
  },
  43114: {
    name: "avalanche", chainId: 43114, rpcEnv: "AVALANCHE_RPC_URL",
    cctpEnabled: true, cctpDomain: 1, lzEid: 30106,
    usdc: "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E", usdcDecimals: 6,
    wrappedNative: "0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7", nativeSymbol: "AVAX",
    uniswapRouter: "0x94b75331ae8d42c1b61065089b7d48fe14aa73b7",
    quoterV2: "0xbe0F5544EC67e9B3b2D979aaA43f18Fd87E6257F",
    stargatePool: "0x5634c4a5FEd09819E3c46D86A965Dd9447d86e47",
    usdcUsdFeed: "0xF096872672F44d6EBA71458D74fe67F9a77a23B9",
    lzComposeGas: 1_200_000, cctpFast: false, // Standard is already ~8 s
    native: { maxPerTx: "0.2", dailyCap: "10", minReserve: "0.5" },
  },
  56: {
    name: "bsc", chainId: 56, rpcEnv: "BSC_RPC_URL",
    cctpEnabled: false, cctpDomain: 0, lzEid: 30102, // no CCTP: Stargate only
    usdc: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", usdcDecimals: 18, // NOTE: BSC USDC has 18 decimals
    wrappedNative: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c", nativeSymbol: "BNB",
    uniswapRouter: "0x1906c1d672b88cd1b9ac7593301ca990f94eae07",
    quoterV2: "0x78D78E420Da98ad378D7799bE8f4AF69033EB077",
    stargatePool: "0x962Bd449E630b0d928f308Ce63f1A21F02576057",
    usdcUsdFeed: "0x51597f405303C4377E36123cBc172b13269EA163",
    lzComposeGas: 1_200_000, cctpFast: false,
    native: { maxPerTx: "0.01", dailyCap: "0.5", minReserve: "0.02" },
  },
};

/** Initial policy values used at deploy time (all owner-configurable afterwards). */
export const POLICY = {
  minSponsorshipUsd: 500,     // >= $500: the vault pays every bridge fee (CCTP fee, LayerZero fee, Stargate token fee)
  bonusThresholdUsd: 20_000,  // >= $20,000: bonus to the sender, in source-chain USDC
  bonusBps: 50,               // bonus = 0.5 % of the swap's USDC
  bonusMaxUsdc: 500,          // ... at most 500 USDC per swap (0 = no cap)
  bonusOncePerWallet: true,   // one bonus per wallet
  bonusDailyCapUsdc: 5_000,   // vault: bonus daily cap
  usdcLimits: { maxPerTx: 100, dailyCap: 2_000, minReserve: 200 }, // vault: USDC fee budget (reserve also protects bonus)
  cctpFastFeeCapPpm: 200,     // vault pays at most Circle minFee + 2 bps for a CCTP Fast fee
  maxSwapFeeBps: 30,          // same-chain swaps: vault refunds Uniswap pool fees up to 0.3 % of the USDC amount
  bonusDelaySec: 0,           // 0 = instant bonus; e.g. 86_400 = claim after 24 h (owners can cancel farming wallets)
  feedMaxStaleness: 86_400 + 3_600, // USDC/USD heartbeat 24h + margin
};

/** Resolve "base" | "8453" | 8453 to a chain. */
export function resolveChain(ref: string | number, chains: Record<number, ChainInfo> = CHAINS): ChainInfo {
  const byId = typeof ref === "number" || /^\d+$/.test(String(ref)) ? chains[Number(ref)] : undefined;
  const c = byId ?? Object.values(chains).find((x) => x.name === String(ref).toLowerCase());
  if (!c) throw new Error(`Unknown chain "${ref}". Known: ${Object.values(chains).map((x) => x.name).join(", ")}`);
  return c;
}
