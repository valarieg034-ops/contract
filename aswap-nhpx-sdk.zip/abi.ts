/**
 * Human-readable ABIs used by the SDK.
 * test/sdk.abi.test.ts checks every fragment against the compiled contracts.
 */

export const DELIVERY_T =
  "tuple(address recipient,address tokenOut,bytes dstPath,uint256 minAmountOut,bool unwrapToNative,uint64 deadline)";
export const SWAP_T =
  `tuple(address tokenIn,uint256 amountIn,bytes srcPath,uint256 minUsdcOut,uint256 dstChainId,uint8 route,bool fastCCTP,uint256 cctpMaxFee,uint256 maxNativeFee,${DELIVERY_T} delivery)`;
const LIMITS_T = "tuple(uint256 maxPerTx,uint256 dailyCap,uint256 minReserve)";
export const CHAIN_T =
  "tuple(bool enabled,bool cctpEnabled,uint32 cctpDomain,uint32 lzEid,address usdc,uint8 usdcDecimals,address wrappedNative,address uniswapRouter,address stargatePool,address hub,uint128 lzComposeGas)";

/** CrossChainSwapHub.LocalSwapParams (same-chain swap, USDC in the middle) */
export const LOCAL_T = "(address tokenIn,uint256 amountIn,bytes pathIn,uint256 minUsdcOut,address tokenOut,bytes pathOut,uint256 minAmountOut,address recipient,bool unwrapToNative,uint64 deadline)";

export const HUB_ABI = [
  // user
  `function swap(${SWAP_T} p, tuple(uint256 nonce,uint256 deadline,bytes signature) permit) payable returns (bytes32)`,
  "function claimUnclaimed(address token,address to)",
  // relay
  "function relayCCTP(bytes message,bytes attestation)",
  // views
  "function quoteEligibility(address user,uint256 usdcAmount) view returns (bool priced,uint256 usd8,bool feeEligible,bool bonusEligible,uint256 bonusAmount,bool bonusClaimed,uint256 bonusAvailable,uint256 vaultNativeAvailable,uint256 vaultUsdcAvailable)",
  `function quoteStargate(uint256 dstChainId,uint256 usdcAmount,${DELIVERY_T} d,bool sponsorTokenFee) view returns (uint256 nativeFee,uint256 amountReceived,uint256 tokenFee)`,
  "function willUseCCTP(uint256 dstChainId,uint8 route) view returns (bool)",
  "function processed(bytes32) view returns (bool)",
  "function unclaimed(address,address) view returns (uint256)",
  "function swapGas() view returns (uint256)",
  "function paused() view returns (bool)",
  "function localChainId() view returns (uint256)",
  "function tokenMessenger() view returns (address)",
  "function messageTransmitter() view returns (address)",
  "function lzEndpoint() view returns (address)",
  "function permit2() view returns (address)",
  "function config() view returns (address)",
  "function vault() view returns (address)",
  "function oracle() view returns (address)",
  "function policy() view returns (address)",
  "function ownerRegistry() view returns (address)",
  // owner
  "function pause()",
  "function unpause()",
  "function setSwapGas(uint256 g)",
  "function setComponents(address c,address v,address o,address pol)",
  "function setBridges(address p2,address tm,address mt,address ep)",
  "function rescueToken(address token,address to,uint256 amount)",
  "function rescueNative(address to,uint256 amount)",
  // events
  "event SwapInitiated(bytes32 indexed transferId,address indexed sender,uint256 indexed dstChainId,address tokenIn,uint256 amountIn,uint256 usdcBridged,bool viaCCTP,bool feeSponsored,bool bonusPaid,address recipient,address tokenOut)",
  "event Delivered(bytes32 indexed id,uint256 indexed srcChainId,address indexed recipient,address tokenOut,uint256 bridgedUsdc,uint256 amountOut,bool swapped)",
  "event SponsorshipUnavailable(address indexed user,uint8 indexed kind,uint256 amount)",
  "event PayoutDeferred(address indexed recipient,address indexed token,uint256 amount)",
  "event SurplusReturned(bytes32 indexed id,uint256 amount)",
  `function swapLocal(${LOCAL_T} p,(uint256 nonce,uint256 deadline,bytes signature) permit) payable returns (uint256)`,
  "function quoteSwapFeeRebate(uint256 usdcAmount,bytes pathIn,bytes pathOut) view returns (uint256)",
  "event LocalSwap(bytes32 indexed id,address indexed sender,address indexed recipient,address tokenIn,uint256 amountIn,uint256 usdcAmount,uint256 swapFeeRebate,address tokenOut,uint256 amountOut,bool bonusPaid)",
  "function unclaimed(address,address) view returns (uint256)",
  "function unclaimedTotal(address) view returns (uint256)",
  "function claimUnclaimed(address token,address to)",
  // errors
  "error FeeNotCovered(uint256 required,uint256 budget,uint256 maxConsent)",
  "error FeeTooHigh()", "error InvalidParams()", "error UnsupportedChain()", "error UnsupportedRoute()",
  "error Expired()", "error Slippage()", "error EnforcedPause()", "error NotOwner(address caller)",
  "error Unauthorized()", "error UntrustedSender()", "error AlreadyProcessed()", "error InsufficientGas()",
  "error Malformed()", "error ReentrancyGuardReentrantCall()",
];

export const REGISTRY_ABI = [
  "function owners() view returns (address[])",
  "function isOwner(address) view returns (bool)",
  "function ownerCount() view returns (uint256)",
  "function addOwner(address account)",
  "function removeOwner(address account)",
  "function replaceOwner(address oldOwner,address newOwner)",
  "error NotOwner(address caller)", "error AlreadyOwner(address account)", "error NotAnOwner(address account)",
  "error CannotRemoveLastOwner()", "error ZeroAddress()",
];

export const POLICY_ABI = [
  "function minSponsorshipUsd8() view returns (uint256)",
  "function bonusThresholdUsd8() view returns (uint256)",
  "function bonusBps() view returns (uint16)",
  "function bonusMaxUsdc() view returns (uint256)",
  "function bonusOncePerWallet() view returns (bool)",
  "function bonusFor(uint256 usdcAmount) view returns (uint256)",
  "function feeCoverEnabled() view returns (bool)",
  "function bonusEnabled() view returns (bool)",
  "function setMinSponsorshipUsd(uint256 usd)",
  "function setBonusThresholdUsd(uint256 usd)",
  "function setThresholds(uint256 minUsd8,uint256 bonusUsd8)",
  "function setBonus(uint16 bps,uint256 maxUsdc,bool oncePerWallet)",
  "function setToggles(bool feeCover,bool bonus)",
  "function cctpFastFeeCapPpm() view returns (uint32)",
  "function maxSwapFeeBps() view returns (uint16)",
  "function setSwapFeeCapBps(uint16 bps)",
  "function setCctpFastFeeCapPpm(uint32 ppm)",
  "function cctpSponsorCap(uint256 amount,uint256 onchainMinFee,bool fast) view returns (uint256)",
  "function initialized() view returns (bool)",
  "error Invalid(string reason)",
];

/** ASwapVault: the single per-chain treasury (native for LayerZero fees, USDC for CCTP / Stargate fees and the bonus). */
export const VAULT_ABI = [
  "function usdc() view returns (address)",
  "function balances() view returns (uint256 native,uint256 usdcBalance)",
  "function availableNative() view returns (uint256)",
  "function availableUsdc() view returns (uint256)",
  "function availableBonus() view returns (uint256)",
  "function nativeLimits() view returns (uint256 maxPerTx,uint256 dailyCap,uint256 minReserve)",
  "function usdcLimits() view returns (uint256 maxPerTx,uint256 dailyCap,uint256 minReserve)",
  "function bonusDailyCap() view returns (uint256)",
  "function nativeUsedToday() view returns (uint256)",
  "function usdcUsedToday() view returns (uint256)",
  "function bonusPaidToday() view returns (uint256)",
  "function isClaimed(address) view returns (bool)",
  "function authorizedHubs(address) view returns (bool)",
  "function paused() view returns (bool)",
  `function setLimits(${LIMITS_T} n,${LIMITS_T} u)`,
  "function setBonusDailyCap(uint256 cap)",
  "function resetBonusClaim(address user)",
  "function bonusDelay() view returns (uint64)",
  "function setBonusDelay(uint64 delay)",
  "function pendingBonus(address) view returns (uint128 amount,uint64 unlockAt)",
  "function totalPendingBonus() view returns (uint256)",
  "function claimBonus()",
  "function cancelBonus(address user)",
  "function initialized() view returns (bool)",
  "function setHubAuthorized(address hub,bool ok)",
  "function withdrawNative(address to,uint256 amount)",
  "function withdrawToken(address token,address to,uint256 amount)",
  "function pause()",
  "function unpause()",
  "event NativeDeposited(address indexed from,uint256 amount)",
  "event BonusPaid(address indexed user,uint256 amount)",
  "event BonusSkipped(address indexed user,uint256 amount,uint8 reason)",
  "event BonusGranted(address indexed user,uint256 amount,uint64 unlockAt)",
  "event BonusCancelled(address indexed user,uint256 amount,address indexed by)",
  "error NothingToClaim()", "error Locked(uint64 unlockAt)",
  "event NativeFeePaid(address indexed hub,uint256 amount)",
  "event UsdcPaid(address indexed hub,uint256 amount)",
];

export const CONFIG_ABI = [
  `function getChain(uint256 chainId) view returns (${CHAIN_T})`,
  "function chainIds() view returns (uint256[])",
  "function eidToChainId(uint32) view returns (uint256)",
  "function domainToChainId(uint32) view returns (uint256)",
  `function setChain(uint256 chainId,${CHAIN_T} p)`,
  "function setHub(uint256 chainId,address hub)",
  "function setEnabled(uint256 chainId,bool enabled)",
];

export const ORACLE_ABI = [
  "function feeds(address) view returns (address aggregator,uint32 maxStaleness)",
  "function tryUsdValue(address token,uint256 amount) view returns (bool ok,uint256 usd8)",
  "function sequencerUptimeFeed() view returns (address)",
  "function setFeed(address token,address aggregator,uint32 maxStaleness)",
  "function setSequencerFeed(address feed,uint32 gracePeriod)",
];

export const ERC20_ABI = [
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address,address) view returns (uint256)",
  "function approve(address,uint256) returns (bool)",
  "function transfer(address,uint256) returns (bool)",
];

export const QUOTER_ABI = [
  "function quoteExactInput(bytes path,uint256 amountIn) returns (uint256 amountOut,uint160[] sqrtPriceX96AfterList,uint32[] initializedTicksCrossedList,uint256 gasEstimate)",
];

export const TOKEN_MESSENGER_V2_ABI = [
  "function getMinFeeAmount(uint256 amount) view returns (uint256)",
];
